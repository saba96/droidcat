
get_features_id<-function(data){
  mf=c(grep("^name|^cl|^malic", names(data)))
  f=setdiff(1:length(names(data)),mf)
  return(f)
}

get_file_name<-function() {
  name=sub("[.][^.]*$","",basename(main))
  name=paste0(prefix,"_",name)
  return(name)
}

get_orca_dir<-function() {
  name=get_file_name()
  orca_target=paste0(path,"orca/",name,suffix)
  return(orca_target)
}

get_susi_sources<-function() {
  res=paste0(path,prefix,"/", susi_list)
  return(res)
}
get_susi_mapping<-function() {
  res=paste0(path,prefix,"/",susi_mapping)
  return(res)
}
get_dfile<-function() {
  res=paste0(prefix,"/",main)    
  return(paste0(path,res))
}

get_score_file<-function() {
  name=get_file_name()
  score_file=paste0(prefix,"/orca_scores_",name)

  score_file=paste0(path,score_file,suffix,".csv")
  return(score_file)
}

get_full_name<-function() {
  name=get_file_name()
  name=paste0(name,suffix)
  return(name)
}

get_results_file<-function() {
  res=paste0(path,"Results.txt")
  return(res)
}

get_fp_dir<-function() {
  dir=paste0(path,"fp_",get_full_name())
  if (!file.exists(dir)){
    dir.create(dir,recursive=TRUE)
  }
  return(dir)
}

to_rds<-function(name) {
  return(gsub("\\.(csv|txt)$",".rds",name))
}