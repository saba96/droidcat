#general
#set root path
path=paste0(normalizePath(paste0(getwd(),"/..")),"/")
options(stringsAsFactors=F)

#use loadRDS to increase the speed of data loading
# do make prepare before
loadRDS=F

#folder with data files (relative to root dir)
prefix="data"

# suffix is used to distinguish different launches
suffix=""

#main data file name
#contains all features (i.e. data flows)
#mandatory fields name;malicious
#name - name of apk
#malicious - 0 or 1, indicating whether an apk is benign or malicious
#all other fields are considered to be features 
#though, 'cl' prefix is reserved for future use 
#it is assumed that sources and sinks are joined by ' -> '
main="main_test.csv"

#file, containing a mapping 'apk'->'susi category of each source within apk'
#format <apk name>;<susi category>
#e.g. com.abc.def.apk;NETWORK_INFORMATION
#no header
susi_list="susi_list_test.csv"

#1st stage
noSUSI=F

#2d stage
orca_disttype="-jaccard"
orca_knn=5
orca_AVERAGE=T
minor_features=c("android.util.Log")
minor_features_weight=0.5#weight for minor data flow features

# minimal number of benign apps in susi category to be processed
minSamples = orca_knn

#4th stage
n.folds=10
n.runs=10
nu=0.15
scale=F
#debug: whether to print false positives
printFP=F







