rm(list = ls())

args = commandArgs(trailingOnly = T)
if (is.na(args[1])) {
   cat("WARNING - no config file specified, using default\n")
   source("conf.R")
} else {
  conf_name=args[1]
  if (!any(grep("*\\.R$",conf_name,ignore.case=T))){
    conf_name=paste0(conf_name,".R")
}
source(conf_name)
}

source("shared.R")

score_file_name=get_score_file()
input_file_name=get_orca_dir()
##############
input_file=paste0(input_file_name,"/scores-all.csv")
res_file=score_file_name
data_file=get_dfile()

outl=read.csv(file=input_file, head=F, sep=";", stringsAsFactors=F)
names(outl)<-c("name","s","score")
susi_sources_file=get_susi_sources()

if (loadRDS){
    data = readRDS(file=to_rds(data_file))
    susi_sources = readRDS(file=to_rds(susi_sources_file))
}else{
    data = read.csv(file=data_file, head=TRUE, sep=";")
    susi_sources = read.csv(file=susi_sources_file, head=F, sep=";" ,stringsAsFactors=F)
}

data=data[,c("name","malicious")]
susi_sources=unique(susi_sources)
names(susi_sources)<-c("name","s")
susi=unique(outl$s)
if (noSUSI){
    susi=c("ALL")
}
scores=data.frame(row.names=data$name,stringsAsFactors=F)
scores=cbind(scores,data[,c("name","malicious")])
#plot scores:
#dev.new()
#par(mfrow=c(4,4),mar=c(1,1,1,1))
weights=list()
for (type in susi){
    soutl=outl[outl$s==type,]
    sdata=susi_sources[susi_sources$s==type,]
    if (noSUSI){
        smdata=data
    }else{
        smdata=data[data$name %in% sdata$name,,drop=F]
    }
    msoutl=merge(soutl[,c("name","score")],smdata,by="name",all.y=T)
    msoutl$score[is.na(msoutl$score)]=0
    msoutl$score[msoutl$score>10000]<-orca_knn
    if (orca_AVERAGE){
        msoutl$score<-msoutl$score/orca_knn# orca outputs sum of distances instead of average
    }

    trainset=msoutl[msoutl$malicious==0,]
    #plot scores
    #barplot(sort(trainset$score),main=type,ylim=c(0,1))
    smean=mean(trainset$score)
    svar=var(trainset$score)
    scores=cbind(scores,rep(0,nrow(data)))
    colnames(scores)[ncol(scores)]<-type
    scores[msoutl[,1],type]<-msoutl[,2]
    weights[[type]]=exp(1/(smean))

    cat(type,"size ",nrow(msoutl)," train size ",nrow(trainset), " var ",svar," mean ",smean," weight ",exp(1/(smean)),"\n")

    if (FALSE){
        #classifier evaluation
        require("ROCR")
        pred=prediction(msoutl$score,msoutl$malicious,label.ordering=c(0,1))
        perf=performance(pred,measure="auc")
        cat("auc ",type,perf@y.values[[1]],"\n")
    }
}
for(type in susi){
    scores[,type]<-scores[,type] * weights[[type]]
}
saveRDS(scores, file = to_rds(res_file))
write.table(scores, file = res_file, quote = F, row.names = F, col.names = T,sep=";")
