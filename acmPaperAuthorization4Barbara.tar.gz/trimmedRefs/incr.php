  <LI>
  Jyh-shiarn Yur, Barbara G. Ryder, and William Landi,
  "An Incremental Flow- and Context-sensitive Pointer Aliasing Analysis",
  <I> Proceedings of the 21st International Conference on Software Engineering (ICSE'99), </I>
  May,
  1999. <P>
   <a href="docs/icse99.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 1999 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. <P>

  <LI>
  Jyh-shiarn Yur, Barbara G. Ryder, William Landi, and Phil Stocks,
  "Incremental Analysis of Side Effects for C Software Systems",
  <I> Proceedings of the 19th International Conference on Software Engineering (ICSE'97), </I>
  May,
  1997. <P>
   <a href="docs/icse97.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 1997 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. <P>

  <LI>
  Jyh-shiarn Yur and Barbara G. Ryder,
  "Incremental Analysis of MOD Problem for C",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-254,
  August,
  1995. <P>
   <a href="docs/lcsr-tr-254.ps.Z">Local</a> <p> 

  <LI>
  T. J. Marlowe and B. G. Ryder,
  "Hybrid Incremental Alias Algorithms",
  <I> Proceedings of the Twentyfourth Hawaii International Conference on System Sciences, Volume II, Software, </I>
  January,
  1991. <P>

  <LI>
  M. Burke and B. G. Ryder,
  "A Critical Analysis of Incremental Iterative Data Flow Analysis Algorithms",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume 16,
  Number 7,
  July,
  1990. <P>
  <B> See also: </B> LCSR-TR-096. <P>

  <LI>
  B. G. Ryder, W. Landi, and H. Pande,
  "Profiling an Incremental Data Flow Analysis Algorithm",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume 16,
  Number 2,
  Pages 129-140,
  February,
  1990. <P>
  <B> See also: </B> CAIP-TR-098. <P>

  <LI>
  T. J. Marlowe and B. G. Ryder,
  "An Efficient Hybrid Algorithm for Incremental Data Flow Analysis",
  <I> Conference Record of the Seventeenth Annual ACM Symposium on Principles of Programming Languages, </I>
  Pages 184-196,
  January,
  1990. <P>
  <B> See also: </B> LCSR-TR-125. <P>

  <LI>
  B. G. Ryder,
  "ISMM: Incremental Software Maintenance Manager",
  <I> Proceedings of the IEEE Computer Society Conference  on Software Maintenance, </I>
  Pages 142-164,
  October,
  1989. <P>

  <LI>
  Thomas J. Marlowe,
  "Data Flow Analysis and Incremental Iteration",
  <I> Rutgers University, Ph.D. Thesis, </I>
  August,
  1989. <P>
  <B> Note: </B> Also available as DCS-TR-255. <P>

  <LI>
  Martin D. Carroll,
  "Dataflow Update via Attribute and Dominator Update",
  <I> Rutgers University, Ph.D. Thesis, </I>
  May,
  1988. <P>
  <B> Note: </B> Also available as LCSR-TR-111. <P>

  <LI>
  Martin Carroll and Barbara G. Ryder,
  "Incremental Data Flow Analysis via Dominator and Attribute Updates",
  <I> Conference Record of the Fifteenth Annual ACM Symposium on Principles of Programming Languages, </I>
  Pages 274-284,
  January,
  1988. <P>

  <LI>
  B. G. Ryder and M. C. Paull,
  "Incremental data-flow analysis algorithms",
  <I> ACM Transactions on Programming Languages and Systems, </I>
  Volume 10,
  Number 1,
  Pages 1-50,
  January,
  1988. <P>
  <B> Note: </B> was DCS-TR-131. <P>

  <LI>
  B. G. Ryder, T.J. Marlowe, and M. C. Paull,
  "Conditions for Incremental Iteration: Examples and Counterexamples",
  <I> Science of Computer Programming, </I>
  Volume 11,
  Pages 1-15,
  1988. <P>
  <B> Note: </B> Also available as LCSR-TR-89. <P>

  <LI>
  B. G. Ryder,
  "An Application of Static Program Analysis to Software Maintenance",
  <I> Proceedings of the Twentieth Hawaii International Conference on System Sciences, Volume II, Software, </I>
  Pages 82-91,
  January,
  1987. <P>

  <LI>
  Martin Carroll and Barbara G. Ryder,
  "An Incremental Algorithm for Software Analysis",
  <I> Proceedings of the ACM SIGSOFT/SIGPLAN Software Engineering Symposium on Practical Software Development Environments, </I>
  Pages 171-179,
  December,
  1986. <P>

  <LI>
  Barbara G. Ryder,
  "Incremental Data Flow Analysis",
  <I> Conference Record of the Tenth Annual ACM Symposium on Principles of Programming Languages, </I>
  Pages 167-176,
  January,
  1983. <P>
