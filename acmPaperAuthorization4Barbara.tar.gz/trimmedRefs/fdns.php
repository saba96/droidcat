 <LI>
  Barbara G. Ryder and Benjamin Weidermann,
  "Languages Design and Analyzability: A Retrospective",
  <I> Software Practice and Experience, </I>
  Volume 42,
  Pages 3-18,
  October,
  2011. <P>
   <a href="http://dx.doi.org/10.1002/spe.1133">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2011 <a href=http://www.wiley.com/go/copyright> John Wiley & Sons </a> available online at wileyonlinelibrary.com. <P>

  <LI>
  Barbara G. Ryder,
  "A Position Paper on Compile-time Program Analysis",
  <I> ACM Computing Surveys, </I>
  Volume 28A,
  Number 4,
  December,
  1996. <P>
   <a href="http://dx.doi.org/10.1145/251595.251615">Digital Library</a> <p> 
  <B> Note: </B> Also appeared in the January 1997 issue of ACM SIGPLAN Notices. <P>

  <LI>
  Stephen P. Masticola,  Thomas J. Marlowe, and Barbara G. Ryder,
  "Lattice frameworks for multisource and bidirectional data flow problems",
  <I> ACM TOPLAS, </I>
  Volume 17,
  Number 5,
  Pages 777-803,
  September,
  1995. <P>
   <a href="docs/lcsr-tr-241.ps.Z">Local</a> <p> 
  <B> Note: </B> Revised version of LCSR-TR-241. <P>

  <LI>
  T. J. Marlowe, B. G. Ryder, and M. Burke,
  "Defining Flow Sensitivity for Data Flow Problems",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-249,
  July,
  1995. <P>
   <a href="docs/lcsr-tr-249.ps.Z">Local</a> <p> 

  <LI>
  T. J. Marlowe and B. G. Ryder,
  "Properties of Data Flow Frameworks: a Unified Model",
  <I> Acta Informatica, </I>
  Volume 28,
  Pages 121-163,
  1990. <P>
   <a href="docs/DataflowFrameworks-Acta90.pdf">Local</a> <p> 

  <LI>
  Barbara G. Ryder and Stephen J. Pendergrast,
  "Experiments in Optimizing FP",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume 14,
  Number 4,
  Pages 444-454,
  April,
  1988. <P>
   <a href="http://dx.doi.org/10.1109/32.4668">Digital Library</a> <p> 

  <LI>
  B. G. Ryder and M. C. Paull,
  "Elimination Algorithms for Data Flow Analysis",
  <I> ACM Computing Surveys, </I>
  Volume 18,
  Number 3,
  Pages 277-316,
  September,
  1986. <P>
  <B> See also: </B> DCS-TR-140. <P>

  <LI>
  A. M. Berman, M. C. Paull, and B. G. Ryder,
  "Proving Relative Lower Bounds for Incremental Algorithms",
  <I> Acta Informatica, </I>
  Volume 27,
  Pages 665-583,
  July,
  199. <P>
  <B> See also: </B> DCS-TR-154 4/85. <P>

