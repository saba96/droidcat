  <LI>
  <B> Security </B> <P>
  Xiaokui Shu, Danfeng Yao, and Barbara Ryder,
  "A Formal Framework for Program Anomaly Detection", 
  <I> Proceedings of the 18th International Symposium on Research in Attacks, Intrusions and Defenses (RAID), </I>
  Nov,
  2015. <P>
   <a href="docs/RAID-2015-Yao.pdf">Local</a> <p>
   <a href="http://link.springer.com/chapter/10.1007%2F978-3-319-26362-5_13">Digital Library</a> <p>
  <B> Note: </B> &copy Copyright 2015 <a href=http://www.springer.com/authors/book+authors/helpdesk?SGWID=0-1723113-12-799504-0> Springer</a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Shiyi Wei, Franceska Xhakaj, and Barbara G. Ryder,
  "Empirical Study of the Dynamic Behavior of JavaScript Objects",
  <I> Software: Practice and Experience, </I>
  May,
  2015. <P>
   <a href="docs/wei15spe.pdf">Local</a> <p>
   <a href="http://onlinelibrary.wiley.com/doi/10.1002/spe.2334/abstract">Digital Library</a> <p>
  <B> Note: </B> &copy Copyright 2015 <a href="http://www.wiley.com/WileyCDA/Section/id-301464.html"> Wiley</a>. <P>

  <LI>
  <B> Security </B> <P>
  Kui Xu and Danfeng Yao and Barbara G. Ryder and Ke Tian,
  "Probabilistic Program Modeling for High Precision Anomaly Classification",
  <I> Proceedings of the Computer Security Foundations Symposium, </I>
  July,
  2015. <P>
   <a href="docs/HMM-CSF-15-Yao.pdf">Local</a> <p>
   <a href="http://ieeexplore.ieee.org/xpl/articleDetails.jsp?reload=true&arnumber=7243750">Digital Library</a> <p>
  <B> Note: </B> &copy Copyright 2015 <a href="https://www.computer.org/web/publications/copyright"> IEEE Computer Society</a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Shiyi Wei and Barbara G. Ryder,
  "Adaptive Context-sensitive Analysis for JavaScript",
  <I> Proceedings of the European Conference on Object-oriented Programming (ECOOP), </I>
  July,
  2015. <P>
   <a href="docs/weiryder-ecoop15.pdf">Local</a> <p>
   <a href="http://drops.dagstuhl.de/opus/volltexte/2015/5244/">Digital Library</a> <p>
  <B> Note: </B> &copy Copyright 2015 <a href="http://drops.dagstuhl.de/doku/urheberrecht1.html"> Dagstuhl</a>. <P>

  <LI>
  <B> Security </B> <P>
  Karim O. Elish and Danfeng Yao and Barbara G. Ryder,
  "Static Characterization of Pairwise Android Inter-component Communications for Collusion Detection",
  <I> Proceedings of the Mobile Security Technologies (MoST), </I>
  May,
  2015. <P>

  <!--<LI>
  <B> Security </B> <P>
  Karim O. Elish and Danfeng Yao and Barbara G. Ryder,
  "Profiling User-trigger Dependence for Android Malware Detection",
  <I> Computers and Society, </I>
  February,
  2015. <P>-->

  <LI>
  <B> Security </B> <P>
  Karim O. Elish, Xiaokui Shu, Danfeng Yao, Barbara Ryder, and Xuxian Jiang. 
  "Profiling User-trigger Dependence for Android Malware Detection",
  <I> Computers & Security (C&S), </I>
  March,
  2015. <P>
   <a href="docs/karim-usertrigger-c&s.pdf">Local</a> <p>
   <a href="http://www.sciencedirect.com/science/article/pii/S0167404814001631">Digital Library</a> <p>
  <B> Note: </B> &copy Copyright 2015 <a href="https://www.elsevier.com/about/company-information/policies/copyright"> Elsevier</a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Shiyi Wei and Barbara G. Ryder,
  "State-sensitive Points-to Analysis for the Dynamic Behavior of JavaScript Objects",
  <I> Proceedings of the European Conference on Object-oriented Programming (ECOOP), </I>
  July,
  2014. <P>
   <a href="docs/weiryder-ecoop14.pdf">Local</a> <p>
   <a href="http://link.springer.com/chapter/10.1007%2F978-3-662-44202-9_1">Digital Library</a> <p>
  <B> Note: </B> &copy Copyright 2014 <a href=http://www.springer.com/authors/book+authors/helpdesk?SGWID=0-1723113-12-799504-0> Springer</a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Shiyi Wei and Barbara G. Ryder,
  "Practical Blended Taint Analysis for JavaScript",
  <I> Proceedings of the 2013 ACM SIGSOFT international symposium on Software testing and analysis(ISSTA 2013), </I>
  July,
  2013. <P>
   <a href="docs/weiryder-issta13.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/2483760.2483788">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2013 <a href=http://www.acm.org/pubs/copyrights.html> ACM</a>. <P>

  <LI>
  <B> Security </B> <P>
  Karim O. Elish and Danfeng Yao and Barbara G. Ryder,
  "User-centric Dependence Analysis for Identifying Malicious Mobile Apps",
  <I> Mobile Security Technologies workshop, </I>
  October,
  2012. <P>
   <a href="http://mostconf.org/2012/papers/20.pdf">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2012 <a href=http://www.ieee.org/portal/index.jsp?pageID=corp_level1&path=about/documentation/copyright&file=index.xml&xsl=generic.xsl>IEEE</a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Shiyi Wei and Barbara G. Ryder,
  "A Practical Blended Analysis for Dynamic Features in JavaScript",
  Number Department of Computer Science, Virginia Tech, TR-12-18,
  September,
  2012. <P>
   <a href="http://eprints.cs.vt.edu/archive/00001206/">Local</a> <p> 

  <LI>
  <B> Foundations of Data Flow Analysis </B> <P>
  Barbara G. Ryder and Benjamin Weidermann,
  "Languages Design and Analyzability: A Retrospective",
  <I> Software Practice and Experience, </I>
  Volume 42,
  Pages 3-18,
  October,
  2011. <P>
   <a href="http://dx.doi.org/10.1002/spe.1133">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2011 <a href=http://www.wiley.com/go/copyright> John Wiley & Sons </a> available online at wileyonlinelibrary.com. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Marc Fisher II and Luke Marrs and Barbara G. Ryder,
  "Hi-C: Diagnosing Object Churn in Framework-Based Applications",
  <I> Proceedings of the Symposium on the Foundations of Software Engineering - Demo Abstract, </I>
  November,
  2010. <P>
   <a href="docs/fse10-demo-bookmarks.pdf">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2010 <a href=http://www.acm.org/pubs/copyrights.html> ACM</a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Marc Fisher II and Bruno Dufour and Shrutarshi Basu and Barbara G. Ryder,
  "Exploring the Impact of Context Sensitivity on Blended Analysis",
  <I> Proceedings of the International Conference on Software Maintenance, </I>
  September,
  2010. <P>
   <a href="docs/icsm2010-bookmarks.pdf">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2010 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Jan Wloka and Einar W. H&oslash;st and Barbara G. Ryder,
  "Tool Support for Change-centric Test Development",
  <I> IEEE Software, </I>
  Volume 27,
  Number 3,
  May/June,
  2010. <P>
   <a href="docs/software10.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1109/MS.2009.159">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2010 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Ali H. Ibrahim and William R. Cook and Marc Fisher II and Eli Tilevich,
  "Remote batch invocation for web services: Document-oriented web services with object-oriented interfaces",
  <I> Proceedings of the European Conference on Web Services, </I>
  Pages {190-199},
  November,
  2009. <P>
   <a href="docs/ibrahim-ecows09.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1109/ECOWS.2009.16">Digital Library</a> <p> 

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Jan Wloka and Barbara G. Ryder and Frank Tip,
  "JUnitMX -- A Change-aware Unit Testing Tool",
  <I> International Conference on Software Engineering, </I>
  May,
  2009. <P>
   <a href="docs/icse09-demo.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1109/ICSE.2009.5070557">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2009 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Jan Wloka and Barbara G. Ryder and Frank Tip and Xiaoxia Ren,
  "Safe-Commit Analysis to Facilitate Team Software Development",
  <I> International Conference on Software Engineering, </I>
  May,
  2009. <P>
   <a href="docs/icse09-committable.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1109/ICSE.2009.5070549">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2009 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Emmanuel Geay and Marco Pistoia and Takaaki Tateishi and Barbara G. Ryder and Julian Dolby,
  "Modular String-Sensitive Permission Analysis with Demand-Driven Precision",
  <I> International Conference on Software Engineering, </I>
  May,
  2009. <P>
   <a href="docs/icse09-permissions.pdf">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2009 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Bruno Dufour and Barbara G. Ryder and Gary Sevitsky,
  "A Scalable Technique for Characterizing the Usage of Temporaries in Framework-Intensive Java Applications",
  <I> Proceedings of the 16th SIGSOFT Conference on the Foundations of Software Engineering, </I>
  November,
  2008. <P>
   <a href="docs/p59-dufour.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/1453101.1453111">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2008 <a href=http://www.acm.org/pubs/copyrights.html> ACM</a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Weilei Zhang and Barbara G. Ryder,
  "Automatic construction of accurate application call graph with library call abstraction for java",
  <I> Journal of Software Maintenance and Evolution: Research and Practice, </I>
  Volume 19,
  Number 4,
  Pages 231-252,
  August,
  2007. <P>
   <a href="http://dx.doi.org/10.1002/smr.351">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2007 <a href=http://www.wiley.com/go/copyright> John Wiley & Sons </a>. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Xiaoxia Ren and Barbara G. Ryder,
  "Heuristic Ranking of Java Program Edits for Fault Localization",
  <I> Proceedings of the 2007 ACM SIGSOFT international symposium on Software testing and analysis(ISSTA 2007), </I>
  July,
  2007. <P>
   <a href="http://dx.doi.org/10.1145/1273463.1273495">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2007 <a href=http://www.acm.org/pubs/copyrights.html> ACM</a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Bruno Dufour and Barbara G. Ryder and Gary Sevitsky,
  "Blended Analysis for Performance Understanding of Framework-based Applications",
  <I> Proceedings of the 2007 ACM SIGSOFT international symposium on Software testing and analysis(ISSTA 2007), </I>
  July,
  2007. <P>
   <a href="docs/dufour-issta07.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/1273463.1273480">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2007 <a href=http://www.acm.org/pubs/copyrights.html> ACM</a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Weilei Zhang and Barbara G. Ryder,
  "Discovering accurate interclass test dependences",
  <I> Proceedings of the Workshop on Program Analysis for Software Tools and Engineering (PASTE 2007), </I>
  Pages 55-62,
  June,
  2007. <P>
   <a href="http://dx.doi.org/10.1145/1251535.1251545">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2007 <a href=http://www.acm.org/pubs/copyrights.html> ACM </a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Chen Fu and Barbara G. Ryder,
  "Exception-Chain Analysis: Revealing Exception Handling Architecture in Java Server Applications",
  <I> icse, </I>
  May,
  2007. <P>
   <a href="http://dx.doi.org/10.1109/ICSE.2007.35">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2007 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Maximilian Stoerzer and Barbara G. Ryder and Xiaoxia Ren and Frank Tip,
  "Finding Failure-Inducing Changes in Java Programs using Change Classification",
  <I> Proceedings of the 14th SIGSOFT Conference on the Foundations of Software Engineering, </I>
  November,
  2006. <P>
   <a href="http://dx.doi.org/10.1145/1181775.1181783">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2006 <a href=http://www.acm.org/pubs/copyrights.html> ACM</a>.. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Xiaoxia Ren and Ophelia C. Chesley and Barbara G. Ryder,
  "Identifying Failure Causes in Java Programs: an Application of Change Impact Analysis",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume 32,
  Pages 718-732,
  September,
  2006. <P>
   <a href="http://dx.doi.org/10.1109/TSE.2006.90">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2006 <a href=http://www.ieee.org/portal/index.jsp?pageID=corp_level1&path=about/documentation/copyright&file=index.xml&xsl=generic.xsl>IEEE</a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Weilei Zhang and Barbara G. Ryder,
  "Constructing Accurate Application Call Graphs for Java to Model Library Callbacks",
  <I> Proceedings of the 6th International Workshop on Source Code Analysis and Manipulation, </I>
  September,
  2006. <P>
   <a href="docs/scam2006.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1109/SCAM.2006.9">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2006 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Chen Fu and Barbara G. Ryder,
  "Exception-chain Analysis: Revealing Exception Handling Architecture in Java Server Applications",
  Number DCS-TR-599,
  March,
  2006. <P>
   <a href="docs/ecchain.pdf">Local</a> <p> 

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Weilei Zhang and Barbara G. Ryder,
  "A Semantics-Based Definition  for Interclass Test Dependence",
  Number DCS-TR-597,
  January,
  2006. <P>
   <a href="docs/dcs-tr-597.pdf">Local</a> <p> 

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Ophelia Chesley, Xiaoxia Ren, Barbara G. Ryder,
  "Crisp: A Debugging Tool for Java Programs",
  <I> Proceedings of the 21st International Conference on Software Maintenance(ICSM 2005), </I>
  September,
  2005. <P>
   <a href="http://dx.doi.org/10.1109/ICSM.2005.37">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2005 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Maximilian Stoerzer and Barbara G. Ryder and Xiaoxia Ren and Frank Tip,
  "Finding Failure-Inducing Changes using Change Classification",
  Number DCS-TR-582,
  September,
  2005. <P>
   <a href="docs/dcs-tr-582.pdf">Local</a> <p> 

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Ana Milanova and Barbara G. Ryder,
  "Annotated Inclusion Constraints for Precise Flow Analysis",
  <I> Proceedings of the 21st International Conference on Software Maintenance(ICSM 2005), </I>
  September,
  2005. <P>
   <a href="http://dx.doi.org/10.1109/ICSM.2005.24">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2005 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Chen Fu and Barbara G. Ryder,
  "Testing and Understanding Error Recovery Code in Java Applications",
  Number DCS-TR-579,
  July,
  2005. <P>
   <a href="docs/dcs-tr-579.ps.Z">Local</a> <p> 
  <B> Note: </B> ECOOP 2005 Workshop on Exception Handling in Object Oriented Systems: Developing Systems that Handle Exceptions. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Weilei Zhang and Barbara G. Ryder,
  "A Practical Algorithm for Interclass Testing Dependence",
  Number DCS-TR-574,
  April,
  2005. <P>
   <a href="ftp://ftp.cs.rutgers.edu/pub/technical-reports/dcs-tr-574.ps.Z">Local</a> <p> 

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Chen Fu, Ana Milanova, Barbara G. Ryder, David Wonnacott,
  "Robustness Testing of Java Server Applications",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume 31,
  Number 4,
  Pages 292-312,
  April,
  2005. <P>
   <a href="http://dx.doi.org/10.1109/TSE.2005.51">Digital Library</a> <p> 
  <B> Note: </B> Extended version of ISSTA 2004 paper solicited for journal publication.. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Ana Milanova, Atanas Rountev, Barbara G. Ryder,
  "Parameterized object sensitivity for points-to analysis for Java",
  <I> ACM Transactions on Software Engineering Methodology, </I>
  Volume 14,
  Number 1,
  Pages 1-41,
  January,
  2005. <P>
   <a href="http://dx.doi.org/10.1145/1044834.1044835">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2004 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. Extended version of ISSTA 2002 paper solicited for journal publication.. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Xiaoxia Ren, Fenil Shah, Frank Tip, Barbara G. Ryder, Ophelia Chesley,
  "Chianti: A Tool for Change Impact Analysis of Java Programs",
  <I> Proceedings of the 19th annual ACM SIGPLAN Conference on Object-oriented programming, systems, languages, and applications(OOPSLA 2004), </I>
  Pages 432-448,
  October,
  2004. <P>
   <a href="docs/oopsla04.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/1035292.1029012">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2004 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. Also available as DCS-TR-551.. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Chen Fu, Barbara Ryder, Ana Milanova, David Wonnacott,
  "Testing of Java Web Services for Robustness",
  <I> Proceedings of the 2004 ACM SIGSOFT international symposium on Software testing and analysis(ISSTA 2004), </I>
  Pages 23-33,
  July,
  2004. <P>
   <a href="http://dx.doi.org/10.1145/1013886.1007516">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2004 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>.   Solicited for submission to special issue of IEEE Transactions on Software Engineering. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Atanas Rountev, Ana Milanova and Barbara G. Ryder,
  "Fragment Class Analysis for Testing Polymorphism in Java Software",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume 30,
  Number 6,
  Pages 372-387,
  June,
  2004. <P>
   <a href="http://dx.doi.org/10.1109/TSE.2004.20">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2004 <a href=http://www.ieee.org/portal/index.jsp?pageID=corp_level1&path=about/documentation/copyright&file=index.xml&xsl=generic.xsl>IEEE</a>, Extended version of ICSE 2003 paper solicited for special issue journal publication.. <P>

  <LI>
  <B> Analysis of C </B> <P>
  Ana Milanova, Atanas Rountev, and Barbara G. Ryder,
  "Precise Call Graphs for C Programs with Function Pointers",
  <I> Automated Software Engineering special issue on Source Code Analysis and Manipulation, </I>
  Volume 11,
  Number 1,
  Pages 7-26,
  January,
  2004. <P>
   <a href="http://dx.doi.org/10.1023/B:AUSE.0000008666.56394.a1">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2004  Kluwer Academic Publishers. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Xiaoxia Ren, Fenil Shah, Frank Tip, Barbara G. Ryder, Ophelia Chesley and Julian Dolby,
  "Chianti: A Prototype Change Impact Analysis Tool for Java",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-533,
  September,
  2003. <P>
   <a href="docs/dcs-tr-533.ps.Z">Local</a> <p> 
  <B> Note: </B> Also available as IBM RC-22983. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Ana Milanova,
  "Precise and Practical Flow Analysis of Object-Oriented Software",
  <I> Rutgers University, Ph.D. Thesis, </I>
  August,
  2003. <P>
   <a href="docs/dcs-tr-539.ps.Z">Local</a> <p> 
  <B> Note: </B> Also available as DCS-TR-539. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Chen Fu, Richard P. Martin, Kiran Nagaraja, Thu D. Nguyen, Barbara G. Ryder, and David G. Wonnacott,
  "Compiler Directed Program-fault Coverage for Highly Available Java Internet Services",
  <I> 2003 International Conference on Dependable Systems and Networks (DSN 2003), </I>
  Pages 595-604,
  June,
  2003. <P>
   <a href="docs/dsn03.pdf">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2003 <a href=http://www.ieee.org/portal/index.jsp?pageID=corp_level1&path=about/documentation/copyright&file=index.xml&xsl=generic.xsl>IEEE</a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Atanas Rountev, Ana Milanova, and Barbara G. Ryder,
  "Fragment Class Analysis for Testing of Polymorphism in Java Software",
  <I> Proceedings of the 25th International Conference on Software Engineering (ICSE 2003), </I>
  Pages 210-220,
  May,
  2003. <P>
   <a href="docs/icse03.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1109/ICSE.2003.1201201">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2003 <a href=http://www.ieee.org/portal/index.jsp?pageID=corp_level1&path=about/documentation/copyright&file=index.xml&xsl=generic.xsl>IEEE</a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  B. G. Ryder,
  "Dimensions of Precision in Reference Analysis of Object-oriented Programming Languages",
  <I> Proceedings of the International Conference on Compiler Construction, </I>
  Pages 126-137,
  April,
  2003. <P>
   <a href="docs/cc03.pdf">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2003 <a href=http://www.springer.de/comp/lncs/>Springer-Verlag</a>. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Matthew Arnold, Michael Hind, and Barbara G. Ryder,
  "Online Feedback-Directed Optimization of Java",
  <I> Proceedings of the 17th ACM SIGPLAN Conference on Object-Oriented Programming, Systems, Languages and Applications (OOPSLA 2002), </I>
  Pages 111-129,
  November,
  2002. <P>
   <a href="docs/oopsla02.ps">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/582419.582432">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2002 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Matthew Arnold,
  "Online Instrumentation and Feedback Directed Optimization of Java",
  <I> Rutgers University, Ph.D. Thesis, </I>
  October,
  2002. <P>
   <a href="docs/dcs-tr-469.ps.Z">Local</a> <p> 
  <B> Note: </B> Also available as DCS-TR-469. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Ana Milanova, Atanas Rountev, and Barbara G. Ryder,
  "Constructing Precise Object Relation Diagrams",
  <I> Proceedings of International Conference on Software Maintenance (ICSM 2002), </I>
  October,
  2002. <P>
   <a href="docs/icsm02.ps">Local</a> <p> 

  <LI>
  <B> Analysis of C </B> <P>
  Ana Milanova, Atanas Rountev, and Barbara G. Ryder,
  "Precise Call Graph Construction in the Presence of Function Pointers",
  <I> Workshop on Source Code Analysis and Manipulation (SCAM 2002), </I>
  October,
  2002. <P>
   <a href="docs/scam02.ps">Local</a> <p> 
   <a href="http://dx.doi.org/10.1109/SCAM.2002.1134115">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2002 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Atanas Rountev,
  "Dataflow Analysis of Software Fragments",
  <I> Rutgers University, Ph.D. Thesis, </I>
  August,
  2002. <P>
  <B> Note: </B> Also available as DCS-TR-501. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Ana Milanova, Atanas Rountev, and Barbara G. Ryder,
  "Parameterized Object Sensitivity for Points-to and Side-Effect Analyses for Java",
  <I> Proceedings of the International Symposium on Software Testing and Analysis (ISSTA 2002), </I>
  July,
  2002. <P>
   <a href="docs/issta02.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2001 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Matthew Arnold and Barbara G. Ryder,
  "Thin Guards: A Simple and Effective Technique for Reducing the Penalty of Dynamic Class Loading",
  <I> Proceedings of the European Conference on Object-Oriented Programming (ECOOP 2002), </I>
  June,
  2002. <P>
   <a href="docs/ecoop02.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2002 <a href=http://www.springer.de/comp/lncs>Springer-Verlag</a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Ana Milanova, Atanas Rountev, and Barbara G. Ryder,
  "Constructing Precise Object Relation Diagrams",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-482,
  March,
  2002. <P>
   <a href="docs/dcs-tr-482.ps">Local</a> <p> 

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Matthew Arnold,
  "Online Instrumentation and Feedback-Directed Optimization of Java",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-469,
  November,
  2001. <P>
   <a href="docs/dcs-tr-469.ps">Local</a> <p> 

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Matthew Arnold and Barbara G. Ryder,
  "Thin Guards: A Simple and Effective Technique for Reducing the Penalty of Dynamic Class Loading",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-470,
  November,
  2001. <P>
   <a href="docs/dcs-tr-470.ps">Local</a> <p> 

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Atanas Rountev, Ana Milanova, and Barbara G. Ryder,
  "Points-to Analysis for Java Using Annotated Constraints",
  <I> Proceedings of the Conference on Object-Oriented Programming, Systems, Languages and Applications (OOPSLA 2001), </I>
  October,
  2001. <P>
   <a href="docs/oopsla01.pdf">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2001 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Matthew Arnold and Barbara G. Ryder,
  "A Framework for Reducing the Cost of Instrumented Code",
  <I> Proceedings of the Conference on Programming Language Design and Implementation (PLDI 2001), </I>
  Pages 168-179,
  June,
  2001. <P>
   <a href="docs/pldi01.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2001 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. Earlier version available as DCS-TR-424. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Barbara G. Ryder and Frank Tip,
  "Change Impact Analysis for Object-Oriented Programs",
  <I> Proceedings of the Workshop on Program Analysis for Software Tools and Engineering (PASTE 2001), </I>
  Pages 46-53,
  June,
  2001. <P>
   <a href="docs/paste01.pdf">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2001 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. Also available as IBM T.J.Watson Reseach Center Technical Report RC21997. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Ramkrishna Chatterjee, Barbara G. Ryder, and William Landi,
  "Complexity of Points-to Analysis of Java in the Presence of Exceptions",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume 27,
  Number 6,
  Pages 481-512,
  June,
  2001. <P>
   <a href="docs/tse01.ps">Local</a> <p> 
  <B> Note: </B> The URL points to a preliminary version. <P>

  <LI>
  <B> Analysis of C </B> <P>
  Ana Milanova, Atanas Rountev, and Barbara G. Ryder,
  "Precise Call Graph Construction in the Presence of Function Pointers",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-442,
  May,
  2001. <P>
   <a href="docs/dcs-tr-442.ps">Local</a> <p> 

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Ramkrishna Chatterjee and Barbara G. Ryder,
  "Data-flow-based Testing of Object-Oriented Libraries",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-433,
  April,
  2001. <P>
   <a href="docs/dcs-tr-433.ps">Local</a> <p> 
  <B> Note: </B> Earlier version available as DCS-TR-382. <P>

  <LI>
  <B> Analysis of C </B> <P>
  Atanas Rountev and Barbara G. Ryder,
  "Points-to and Side-effect Analyses for Programs Built with Precompiled Libraries",
  <I> Proceedings of the International Conference on Compiler Construction (CC 2001), </I>
  April,
  2001. <P>
   <a href="docs/cc01.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2001 <a href=http://www.springer.de/comp/lncs>Springer-Verlag</a>. Earlier version available as DCS-TR-423. <P>

  <LI>
  <B> Analysis of C </B> <P>
  Barbara G. Ryder, William Landi, Philip A. Stocks, Sean Zhang, and Rita Altucher,
  "A schema for interprocedural modification side-effect analysis with pointer aliasing",
  <I> ACM Transactions on Programming Languages and Systems, </I>
  Volume 23,
  Pages 105-186,
  March,
  2001. <P>
   <a href="docs/toplas01.ps">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/383043.381532">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2001 <a href=http://www.acm.org/pubs/copyrights.html> ACM</a>. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Atanas Rountev, Ana Milanova, and Barbara G. Ryder,
  "Class Analysis for Testing of Polymorphism in Java Software",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-432,
  February,
  2001. <P>
   <a href="docs/dcs-tr-432.ps.Z">Local</a> <p> 

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Matthew Arnold, Michael Hsiao, Ulrich Kremer, and Barbara G. Ryder,
  "Exploring the Interaction between Java's Implicitly Thrown Exceptions and Instruction Scheduling",
  <I> International Journal of Parallel Programming, special issue, </I>
  Volume 29,
  Pages 111-137,
  2001. <P>
   <a href="http://dx.doi.org/10.1023/A:1007621602134">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2001  Kluwer Academic Publishers. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Matthew Arnold and Barbara G. Ryder,
  "A Framework for Reducing the Cost of Instrumented Code",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-424,
  November,
  2000. <P>
   <a href="docs/dcs-tr-424.ps.Z">Local</a> <p> 

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Atanas Rountev, Ana Milanova, and Barbara G. Ryder,
  "Points-to Analysis for Java Based on Annotated Constraints",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-428,
  November,
  2000. <P>
   <a href="docs/dcs-tr-428.ps.Z">Local</a> <p> 
  <B> Note: </B> Supersedes DCS-TR-417. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Matthew Arnold, Stephen Fink, David Grove, Michael Hind, and Peter Sweeney,
  "Adaptive Optimization in the Jalapeno JVM",
  <I> Proceedings of the Conference on Object-Oriented Programming, Systems, Languages and Applications (OOPSLA 2000), </I>
  October,
  2000. <P>
   <a href="docs/oopsla00.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/353171.353175">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2000 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. <P>

  <LI>
  <B> Analysis of C </B> <P>
  Atanas Rountev and Barbara G. Ryder,
  "Points-to and Side-effect Analyses for Programs Built with Precompiled Libraries",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-423,
  October,
  2000. <P>
   <a href="docs/dcs-tr-423.ps.Z">Local</a> <p> 

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Matthew Arnold, Michael Hind, and Barbara G. Ryder,
  "An Empirical Study of Selective Optimization",
  <I> Proceedings of the International Workshop on Languages and Compilers for Parallel Computing (LCPC 2000), </I>
  August,
  2000. <P>
   <a href="docs/lcpc00.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2000 <a href=http://www.springer.de/comp/lncs>Springer-Verlag</a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Atanas Rountev, Ana Milanova, and Barbara G. Ryder,
  " Points-to Analysis for Java Using Annotated Inclusion Constraints",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-417,
  July,
  2000. <P>
   <a href="docs/dcs-tr-417.ps.Z">Local</a> <p> 

  <LI>
  <B> Analysis of C </B> <P>
  Atanas Rountev and Satish Chandra,
  "Off-line Variable Substitution for Scaling Points-to Analysis",
  <I> Proceedings of the Conference on Programming Language Design and Implementation (PLDI 2000), </I>
  June,
  2000. <P>
   <a href="docs/pldi00.ps">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/349299.349310">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2000 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Matthew Arnold, Michael Hind, and Barbara G. Ryder,
  "An Empirical Study of Selective Optimization",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-411,
  March,
  2000. <P>
   <a href="docs/dcs-tr-411.ps.Z">Local</a> <p> 

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Barbara G. Ryder, Donald Smith, Ulrich Kremer, Michael Gordon, and Nirav Shah,
  "A Static Study of Java Exceptions",
  <I> Proceedings of the 9th International Conference on Compiler Construction (CC 2000), </I>
  March,
  2000. <P>
   <a href="docs/cc00.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2000 <a href=http://www.springer.de/comp/lncs>Springer-Verlag</a>. Earlier version available as DCS-TR-403. <P>

  <LI>
  <B> Analysis of C </B> <P>
  Atanas Rountev and Barbara G. Ryder,
  "Practical Points-to Analysis for Programs Built with Libraries",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-410,
  February,
  2000. <P>
   <a href="docs/dcs-tr-410.ps.Z">Local</a> <p> 

  <LI>
  <B> Performance Estimation </B> <P>
  Chung-Hsing Hsu and Ulrich Kremer,
  "A Stable and Efficient Loop Tiling Algorithm",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-407,
  December,
  1999. <P>
   <a href="docs/dcs-tr-407.ps.Z">Local</a> <p> 

  <LI>
  <B> Performance Estimation </B> <P>
  Chung-Hsing Hsu and Ulrich Kremer,
  "Tile Selection Algorithms and Their Performance Models",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-401,
  October,
  1999. <P>
   <a href="docs/dcs-tr-401.ps.Z">Local</a> <p> 

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Ramkrishna Chatterjee,
  "Modular Data-flow Analysis of Statically Typed Object-Oriented Programming Languages",
  <I> Rutgers University, Ph.D. Thesis, </I>
  October,
  1999. <P>
   <a href="docs/dcs-tr-406.ps.Z">Local</a> <p> 
  <B> Note: </B> Available as DCS-TR-406. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Barbara G. Ryder, Donald Smith, Ulrich Kremer, Michael Gordon, and Nirav Shah,
  "A Static Study of Java Exceptions using JESP",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-403,
  October,
  1999. <P>
   <a href="docs/dcs-tr-403.ps.Z">Local</a> <p> 

  <LI>
  <B> Analysis of C </B> <P>
  Atanas Rountev, Barbara G. Ryder, and William Landi,
  "Data-Flow Analysis of Program Fragments",
  <I> Proceedings of the 7th Symposium on the Foundations of Software Engineering (FSE'99), LNCS 1687, </I>
  September,
  1999. <P>
   <a href="docs/fse99.ps">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/318773.318945">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 1999 <a href=http://www.springer.de/comp/lncs>Springer-Verlag</a>. Earlier version available as DCS-TR-383. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Matthew Arnold, Michael Hsiao, Ulrich Kremer, and Barbara G. Ryder,
  "Instruction Scheduling in the Presence of Java's Runtime Exceptions",
  <I> Proceedings of the 12th Workshop on Languages and Compilers for Parallel Computing (LCPC'99), </I>
  August,
  1999. <P>
  <B> Note: </B> &copy Copyright 2000 <a href=http://www.springer.de/comp/lncs>Springer-Verlag</a>. Earlier version available as DCS-TR-403. <P>

  <LI>
  <B> Analysis of C </B> <P>
  Jyh-shiarn Yur,
  "Incremental Analysis for Flow- and Context-Sensitive Data-Flow Problems",
  <I> Rutgers University, Ph.D. Thesis, </I>
  July,
  1999. <P>
   <a href="docs/dcs-tr-393.ps.Z">Local</a> <p> 
  <B> Note: </B> Available as DCS-TR-393. <P>

  <LI>
  <B> Software Tools and Optimizations for Object-Oriented Languages </B> <P>
  Matthew Arnold, Michael Hsiao, Ulrich Kremer, and Barbara G. Ryder,
  "Instruction Scheduling in the Presence of Java's Runtime Exceptions",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-384,
  June,
  1999. <P>
   <a href="docs/dcs-tr-384.ps.Z">Local</a> <p> 
  <B> Note: </B> Earlier version of the LCPC'99 paper. <P>

  <LI>
  <B> Incremental Data Flow Analysis </B> <P>
  Jyh-shiarn Yur, Barbara G. Ryder, and William Landi,
  "An Incremental Flow- and Context-sensitive Pointer Aliasing Analysis",
  <I> Proceedings of the 21st International Conference on Software Engineering (ICSE'99), </I>
  May,
  1999. <P>
   <a href="docs/icse99.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 1999 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Ramkrishna Chatterjee and Barbara G. Ryder,
  "Data-flow-based Testing of Object-Oriented Libraries",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-382,
  March,
  1999. <P>
   <a href="docs/dcs-tr-382.ps.Z">Local</a> <p> 

  <LI>
  <B> Analysis of C </B> <P>
  Atanas Rountev, Barbara G. Ryder, and William Landi,
  "Data-Flow Analysis of Program Fragments",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-383,
  March,
  1999. <P>
   <a href="docs/dcs-tr-383.ps.Z">Local</a> <p> 
  <B> Note: </B> Earlier version of the FSE'99 paper. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  R. Chatterjee, B. G. Ryder, and W. Landi,
  "Relevant Context Inference",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-360,
  January,
  1999. <P>
   <a href="docs/dcs-tr-360.ps.Z">Local</a> <p> 
  <B> Note: </B> Longer version of the POPL'99 paper - more on exceptions, libraries, and testing. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Ramkrishna Chatterjee, Barbara G. Ryder, and William Landi,
  "Relevant Context Inference",
  <I> Proceedings of the 26th ACM SIGACT/SIGPLAN Symposium on Principles of Programming Languages (POPL'99), </I>
  January,
  1999. <P>
   <a href="docs/popl99.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 1999 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. Longer version available as DCS-TR-360. <P>

  <LI>
  <B> Performance Estimation </B> <P>
  Chung-Hsing Hsu and Ulrich Kremer,
  "IPERF: A Framework for Automatic Construction of Performance Prediction Models",
  <I> First Workshop on Profile and Feedback-Directed Compilation, </I>
  October,
  1998. <P>
   <a href="docs/PFDC98.ps">Local</a> <p> 

  <LI>
  <B> Analysis of C </B> <P>
  Xiang-Xiang Sean Zhang,
  "Practical Pointer Aliasing Analyses for C",
  <I> Rutgers University, Ph.D. Thesis, </I>
  August,
  1998. <P>
   <a href="docs/dcs-tr-367.ps.Z">Local</a> <p> 
  <B> Note: </B> Available as DCS-TR-367. <P>

  <LI>
  <B> Performance Estimation </B> <P>
  Chung-Hsing Hsu and Ulrich Kremer,
  "A Framework for Qualitative Performance Prediction",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-363,
  July,
  1998. <P>
   <a href="docs/dcs-tr-363.ps.Z">Local</a> <p> 

  <LI>
  <B> Analysis of C </B> <P>
  Sean Zhang, Barbara G. Ryder, and William Landi,
  "Experiments with Combined Analysis for Pointer Aliasing",
  <I> Proceedings of the Workshop on Program Analysis for Software Tools and Engineering (PASTE'98), </I>
  June,
  1998. <P>
   <a href="docs/dcs-tr-350.ps.Z">Local</a> <p> 
  <B> Note: </B> Also available as DCS-TR-350. <P>

  <LI>
  <B> Analysis of C </B> <P>
  B. G. Ryder, W. Landi, P. Stocks, S. Zhang, and R. Altucher,
  "A Schema for Interprocedural Side Effect Analysis with Pointer Aliasing",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-336,
  May,
  1998. <P>
   <a href="docs/revision.pdf">Local</a> <p> 
  <B> Note: </B> Revised for journal August 1999. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Ramkrishna Chatterjee, Barbara G. Ryder, and William Landi,
  "Complexity of Concrete Type-Inference in the Presence of Exceptions",
  <I> Proceedings of the European Symposium on Programming (ESOP'98), LNCS 1381, </I>
  April,
  1998. <P>
   <a href="docs/esop98.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 1998 <a href=http://www.springer.de/comp/lncs>Springer-Verlag</a>. Longer version available as DCS-TR-341. <P>

  <LI>
  <B> Analysis of C </B> <P>
  P. Stocks, B. G. Ryder, W. Landi, and S. Zhang,
  "Comparing Flow and Context Sensitivity on the Modification-side-effects Problem",
  <I> Proceedings of the International Symposium on Software Testing and Analysis (ISSTA'98), </I>
  Pages 21-31,
  March,
  1998. <P>
   <a href="docs/dcs-tr-335.ps.Z">Local</a> <p> 
  <B> Note: </B> Also available as DCS-TR-335. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  R. Chatterjee and B. G Ryder,
  "Modular Concrete Type-Inference for Statically Typed Object-Oriented Programming Languages",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-349,
  November,
  1997. <P>
   <a href="docs/dcs-tr-349.ps.Z">Local</a> <p> 

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  R. Chatterjee, B. G. Ryder, and W. Landi,
  "Complexity of Concrete Type-Inference in the Presence of Exceptions",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-341,
  September,
  1997. <P>
   <a href="docs/dcs-tr-341.ps.Z">Local</a> <p> 
  <B> Note: </B> Longer version of the ESOP'98 paper. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  R. Chatterjee and B. G. Ryder,
  "Scalable, Flow-Sensitive Type-Inference for Statically Typed Object-Oriented Programming Languages",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-326,
  July,
  1997. <P>
   <a href="docs/dcs-tr-326.ps.Z">Local</a> <p> 

  <LI>
  <B> Incremental Data Flow Analysis </B> <P>
  Jyh-shiarn Yur, Barbara G. Ryder, William Landi, and Phil Stocks,
  "Incremental Analysis of Side Effects for C Software Systems",
  <I> Proceedings of the 19th International Conference on Software Engineering (ICSE'97), </I>
  May,
  1997. <P>
   <a href="docs/icse97.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 1997 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. <P>

  <LI>
  <B> Foundations of Data Flow Analysis </B> <P>
  Barbara G. Ryder,
  "A Position Paper on Compile-time Program Analysis",
  <I> ACM Computing Surveys, </I>
  Volume 28A,
  Number 4,
  December,
  1996. <P>
   <a href="http://dx.doi.org/10.1145/251595.251615">Digital Library</a> <p> 
  <B> Note: </B> Also appeared in the January 1997 issue of ACM SIGPLAN Notices. <P>

  <LI>
  <B> Analysis of C </B> <P>
  Sean Zhang, Barbara G. Ryder, and William Landi,
  "Program Decomposition for Pointer Aliasing: A Step toward Practical Analyses",
  <I> Proceedings of the 4th Symposium on the Foundations of Software Engineering (FSE'96), </I>
  October,
  1996. <P>
   <a href="docs/fse96.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 1996 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. Longer version available as LCSR-TR-259. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Hemant Pande and Barbara G. Ryder,
  "Data-flow-based Virtual Function Resolution",
  <I> Static Analysis: Third International Symposium (SAS'96), LNCS 1145, </I>
  Pages 238-254,
  September,
  1996. <P>
   <a href="docs/sas96.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 1996  <a href=http://www.springer.de/comp/lncs>Springer-Verlag</a>. <P>

  <LI>
  <B> Parallel Data Flow Analysis </B> <P>
  Javier Elices,
  "Refining the Parallel Hybrid Algorithm for Data Flow Analysis",
  <I> Rutgers University, M. S. Thesis, </I>
  May,
  1996. <P>
  <B> Note: </B> Available as LCSR-TR-261. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Hemant D. Pande,
  "Compile Time Analysis of C and C++ Systems",
  <I> Rutgers University, Ph.D. Thesis, </I>
  May,
  1996. <P>
   <a href="docs/lcsr-tr-260.ps.Z">Local</a> <p> 
  <B> Note: </B> Available as LCSR-TR-260. <P>

  <LI>
  <B> Analysis of C </B> <P>
  Sean Zhang, Barbara G. Ryder, and William Landi,
  "Program Decomposition for Pointer-induced Aliasing Analysis",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-259,
  March,
  1996. <P>
   <a href="docs/lcsr-tr-259.ps.Z">Local</a> <p> 
  <B> Note: </B> Longer version of the FSE'96 paper. <P>

  <LI>
  <B> Parallel Data Flow Analysis </B> <P>
  Javier Elices,
  "The FM and PL Libraries Documentation",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-257,
  January,
  1996. <P>
   <a href="docs/lcsr-tr-257-part1of3.ps.Z">Local</a> <p> 
  <B> Note: </B> This is a three part document. The URL here points to the first part of the document. The URL's to the other parts are similar, but end with 'part2of3.ps' and 'part3of3.ps'. <P>

  <LI>
  <B> Parallel Data Flow Analysis </B> <P>
  Yong-fong Lee, Barbara G. Ryder, and Marc E. Fiuczynski,
  "Region Analysis: A Parallel Elimination Method for Data Flow Analysis",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume SE-21,
  Number 11,
  Pages 913-926,
  November,
  1995. <P>
   <a href="http://citeseer.ist.psu.edu/18168.html">Local</a> <p> 

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  Hemant Pande and Barbara G. Ryder,
  "Static Type Determination and Aliasing for C++",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-250-A,
  October,
  1995. <P>
   <a href="docs/lcsr-tr-250-a.ps.Z">Local</a> <p> 

  <LI>
  <B> Foundations of Data Flow Analysis </B> <P>
  Stephen P. Masticola,  Thomas J. Marlowe, and Barbara G. Ryder,
  "Lattice frameworks for multisource and bidirectional data flow problems",
  <I> ACM TOPLAS, </I>
  Volume 17,
  Number 5,
  Pages 777-803,
  September,
  1995. <P>
   <a href="docs/lcsr-tr-241.ps.Z">Local</a> <p> 
  <B> Note: </B> Revised version of LCSR-TR-241. <P>

  <LI>
  <B> Incremental Data Flow Analysis </B> <P>
  Jyh-shiarn Yur and Barbara G. Ryder,
  "Incremental Analysis of MOD Problem for C",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-254,
  August,
  1995. <P>
   <a href="docs/lcsr-tr-254.ps.Z">Local</a> <p> 

  <LI>
  <B> Foundations of Data Flow Analysis </B> <P>
  T. J. Marlowe, B. G. Ryder, and M. Burke,
  "Defining Flow Sensitivity for Data Flow Problems",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-249,
  July,
  1995. <P>
   <a href="docs/lcsr-tr-249.ps.Z">Local</a> <p> 

  <LI>
  <B> Analysis of C </B> <P>
  A. Shah and B. G. Ryder,
  "Function Pointers in C -- An Empirical Study",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-244,
  May,
  1995. <P>
   <a href="docs/lcsr-tr-244.ps.Z">Local</a> <p> 

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  H. Pande and B. G. Ryder,
  "Static Type Determination and Aliasing for C++",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-236,
  December,
  1994. <P>
   <a href="docs/lcsr-tr-236.ps.Z">Local</a> <p> 

  <LI>
  <B> Analysis of C </B> <P>
  S. Zhang and B. G. Ryder,
  "Complexity of Single Level Function Pointer Aliasing Analysis",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-233,
  October,
  1994. <P>
   <a href="docs/lcsr-tr-233.ps.Z">Local</a> <p> 

  <LI>
  <B> Parallel Data Flow Analysis </B> <P>
  Vincent Sgro and Barbara G. Ryder,
  "Differences in Algorithmic Parallelism in Control Flow and Call Multigraphs",
  <I> Proceedings of the Seventh Annual Workshop on Languages and Compilers for Parallel Computing, LNCS 892, </I>
  Pages 217-233,
  August,
  1994. <P>
  <B> See also: </B> HPCD-TR-11. <P>

  <LI>
  <B> Parallel Data Flow Analysis </B> <P>
  Yong-fong Lee, Barbara G. Ryder, and Marc. E. Fiuczynski,
  "Region Analysis: A Parallel Elimination Method for Data Flow Analysis",
  <I> Proceedings of the IEEE Conference on Computer Languages, </I>
  Pages 31-42,
  May,
  1994. <P>

  <LI>
  <B> Analysis of C </B> <P>
  H. Pande, W. Landi, and B. G. Ryder,
  "Interprocedural Def-Use Associations for C Systems with Single Level Pointers",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume 20,
  Number 5,
  Pages 385-403,
  May,
  1994. <P>
  <B> Note: </B> Earlier version available as LCSR-TR-193. <P>

  <LI>
  <B> Analysis of Object-Oriented Languages </B> <P>
  H. Pande and B. G. Ryder,
  "Static Type Determination for C++",
  <I> Proceedings of the Sixth USENIX C++ Technical Conference, </I>
  Pages 85-97,
  April,
  1994. <P>

  <LI>
  <B> Parallel Data Flow Analysis </B> <P>
  Yong-fong Lee and Barbara G. Ryder,
  "Effectively Exploiting Parallelism in Data Flow Analysis",
  <I> The Journal of Supercomputing, </I>
  Pages 233-262,
  1994. <P>
  <B> See also: </B> LCSR-TR-192. <P>

  <LI>
  <B> Analysis of C </B> <P>
  T. J. Marlowe, W. Landi, B. G. Ryder, J. Choi, M. Burke, and P. Carini,
  "Pointer-induced Aliasing: A Clarification",
  <I> ACM SIGPLAN Notices, </I>
  Volume 28,
  Number 9,
  Pages 67-70,
  September,
  1993. <P>

  <LI>
  <B> Analysis of C </B> <P>
  W. Landi, B. G. Ryder, and S. Zhang,
  "Interprocedural Modification Side Effect Analysis With Pointer Aliasing",
  <I> Proceedings of the SIGPLAN '93 Conference on Programming Language Design and Implementation, </I>
  Pages 56-67,
  June,
  1993. <P>
  <B> See also: </B> LCSR-TR-201, LCSR-TR-195. <P>

  <LI>
  <B> Analysis of Explicitly Parallel Programs </B> <P>
  Stephen Masticola,
  "Static Detection of Deadlocks in Polynomial Time",
  <I> Rutgers University, Ph.D. Thesis, </I>
  May,
  1993. <P>
   <a href="docs/lcsr-tr-208.ps.Z">Local</a> <p> 
  <B> Note: </B> Also available as LCSR-TR-208. <P>

  <LI>
  <B> Analysis of Explicitly Parallel Programs </B> <P>
  S. Masticola and B. G. Ryder,
  "Non-concurrency Analysis",
  <I>  Proceedings of Conference on Principles and Practices of Parallel Programming, </I>
  Pages 129-138,
  May,
  1993. <P>
  <B> Note: </B> Published as ACM SIGPLAN Notices, May 1993. <P>

  <LI>
  <B> Analysis of C </B> <P>
  W. Landi, B. G. Ryder, and S. Zhang,
  "Interprocedural Modification Side Effect Analysis With Pointer Aliasing",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-201,
  March,
  1993. <P>
   <a href="docs/lcsr-tr-201.ps.Z">Local</a> <p> 
  <B> Note: </B> This report supersedes LCSR-TR-195 and is an expansion of the ACM SIGPLAN PLDI'93 paper. <P>

  <LI>
  <B> Parallel Data Flow Analysis </B> <P>
  Yong-fong Lee and Barbara G. Ryder,
  "Parallel Hybrid Data Flow Algorithms: A Case Study",
  <I> Conference Record of 5th Workshop on Languages and Compilers for Parallel Computing, Yale University, LNCS 757, </I>
  Pages 296-310,
  August,
  1992. <P>

  <LI>
  <B> Analysis of Explicitly Parallel Programs </B> <P>
  E. Schatz and B. G. Ryder,
  "Directed Tracing to Detect Race Conditions",
  <I> Proceedings of the International Conference on Parallel Processing, </I>
  August,
  1992. <P>
  <B> Note: </B> Longer version available as LCSR-TR-176. <P>

  <LI>
  <B> Parallel Data Flow Analysis </B> <P>
  Yong-fong Lee and Barbara G. Ryder,
  "A Comprehensive Approach to Parallel Data Flow Analysis",
  <I> Proceedings of the ACM International Conference on Supercomputing, </I>
  Pages 236-247,
  July,
  1992. <P>

  <LI>
  <B> Analysis of C </B> <P>
  W. Landi and B. G. Ryder,
  "A safe approximate algorithm for interprocedural aliasing",
  <I> Proceedings of the SIGPLAN '92 Conference on Programming Language Design and Implementation, </I>
  Pages 235-248,
  June,
  1992. <P>
  <B> See also: </B> LCSR-TR-168. <P>

  <LI>
  <B> Parallel Data Flow Analysis </B> <P>
  Yong-fong Lee,
  "Performing Data Flow Analysis in Parallel",
  <I> Rutgers University, Ph.D. Thesis, </I>
  May,
  1992. <P>
  <B> Note: </B> Also available as LCSR-TR-215. <P>

  <LI>
  <B> Analysis of Explicitly Parallel Programs </B> <P>
  E. Schatz and B. G. Ryder,
  "Directed Tracing to Detect Race Conditions",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-176,
  January,
  1992. <P>
  <B> Note: </B>  This is a fuller version of the ICPP92 paper. <P>

  <LI>
  <B> Analysis of C </B> <P>
  William A. Landi,
  "Interprocedural Aliasing in the Presence of Pointers",
  <I> Rutgers University, Ph.D. Thesis, </I>
  January,
  1992. <P>
   <a href="docs/lcsr-tr-174.ps.Z">Local</a> <p> 
  <B> Note: </B> Also available as LCSR-TR-174. <P>

  <LI>
  <B> Parallel Data Flow Analysis </B> <P>
  Yong-fong Lee, Thomas J. Marlowe, and Barbara G. Ryder,
  "Experiences with a Parallel Algorithm for Data Flow Analysis",
  <I> The Journal of Supercomputing, </I>
  Volume 5,
  Number 2,
  Pages 163-188,
  October,
  1991. <P>

  <LI>
  <B> Analysis of C </B> <P>
  H. Pande, B. G. Ryder, and W. Landi,
  "Interprocedural Def-Use Associations for C Programs",
  <I> Proceedings of the ACM SIGSOFT Conference on Testing, Analysis and Verification, </I>
  Pages 139-153,
  October,
  1991. <P>

  <LI>
  <B> Analysis of C </B> <P>
  W. Landi and B. G. Ryder,
  "A safe approximation algorithm for interprocedural pointer aliasing",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-168,
  September,
  1991. <P>
   <a href="docs/lcsr-tr-168.ps.Z">Local</a> <p> 
  <B> Note: </B> a fuller version of PLDI'92 paper. <P>

  <LI>
  <B> Analysis of Explicitly Parallel Programs </B> <P>
  S. Masticola and B. G. Ryder,
  "A model of Ada programs for static deadlock detection in polynomial times",
  <I>  Proceedings of 1991 ACM/ONR Workshop on Parallel and, </I>
  Pages 91-102,
  May,
  1991. <P>
  <B> Note: </B> Published as ACM SIGPLAN Notices, vol 26, no 12, December 1991. <P>

  <LI>
  <B> Analysis of C </B> <P>
  H. Pande, B. G. Ryder, and W. Landi,
  "Interprocedural Def-Use Associations in C Programs",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-162,
  April,
  1991. <P>

  <LI>
  <B> Incremental Data Flow Analysis </B> <P>
  T. J. Marlowe and B. G. Ryder,
  "Hybrid Incremental Alias Algorithms",
  <I> Proceedings of the Twentyfourth Hawaii International Conference on System Sciences, Volume II, Software, </I>
  January,
  1991. <P>

  <LI>
  <B> Analysis of C </B> <P>
  W. Landi and B. G. Ryder,
  "Pointer-induced Aliasing: A Problem Classification",
  <I> Conference Record of the Eighteenth Annual ACM Symposium on Principles of Programming Languages, </I>
  Pages 93-103,
  January,
  1991. <P>

  <LI>
  <B> Parallel Data Flow Analysis </B> <P>
  Yong-fong Lee, Thomas J. Marlowe, and Barbara G. Ryder,
  "Performing Data Flow Analysis in Parallel",
  <I> Proceedings of ACM Supercomputing90, </I>
  Pages 942-951,
  November,
  1990. <P>
  <B> See also: </B> CAIP-TR-108. <P>

  <LI>
  <B> Analysis of Explicitly Parallel Programs </B> <P>
  E. Schatz and B. G. Ryder,
  "Directed Tracing to Detect Race Conditions",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-155,
  November,
  1990. <P>

  <LI>
  <B> Analysis of Explicitly Parallel Programs </B> <P>
  S. Masticola and B. G. Ryder,
  "Static Infinite Wait Anomaly Detection in Polynomial Time",
  <I> Proceedings of the International Conference on Parallel Processing, </I>
  Pages II78-II87,
  August,
  1990. <P>
  <B> Note: </B> Longer version available as LCSR-TR-141. <P>

  <LI>
  <B> Incremental Data Flow Analysis </B> <P>
  M. Burke and B. G. Ryder,
  "A Critical Analysis of Incremental Iterative Data Flow Analysis Algorithms",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume 16,
  Number 7,
  July,
  1990. <P>
  <B> See also: </B> LCSR-TR-096. <P>

  <LI>
  <B> Incremental Data Flow Analysis </B> <P>
  B. G. Ryder, W. Landi, and H. Pande,
  "Profiling an Incremental Data Flow Analysis Algorithm",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume 16,
  Number 2,
  Pages 129-140,
  February,
  1990. <P>
  <B> See also: </B> CAIP-TR-098. <P>

  <LI>
  <B> Incremental Data Flow Analysis </B> <P>
  T. J. Marlowe and B. G. Ryder,
  "An Efficient Hybrid Algorithm for Incremental Data Flow Analysis",
  <I> Conference Record of the Seventeenth Annual ACM Symposium on Principles of Programming Languages, </I>
  Pages 184-196,
  January,
  1990. <P>
  <B> See also: </B> LCSR-TR-125. <P>

  <LI>
  <B> Foundations of Data Flow Analysis </B> <P>
  T. J. Marlowe and B. G. Ryder,
  "Properties of Data Flow Frameworks: a Unified Model",
  <I> Acta Informatica, </I>
  Volume 28,
  Pages 121-163,
  1990. <P>
   <a href="docs/DataflowFrameworks-Acta90.pdf">Local</a> <p> 

  <LI>
  <B> Incremental Data Flow Analysis </B> <P>
  B. G. Ryder,
  "ISMM: Incremental Software Maintenance Manager",
  <I> Proceedings of the IEEE Computer Society Conference  on Software Maintenance, </I>
  Pages 142-164,
  October,
  1989. <P>

  <LI>
  <B> Incremental Data Flow Analysis </B> <P>
  Thomas J. Marlowe,
  "Data Flow Analysis and Incremental Iteration",
  <I> Rutgers University, Ph.D. Thesis, </I>
  August,
  1989. <P>
  <B> Note: </B> Also available as DCS-TR-255. <P>

  <LI>
  <B> Incremental Data Flow Analysis </B> <P>
  Martin D. Carroll,
  "Dataflow Update via Attribute and Dominator Update",
  <I> Rutgers University, Ph.D. Thesis, </I>
  May,
  1988. <P>
  <B> Note: </B> Also available as LCSR-TR-111. <P>

  <LI>
  <B> Foundations of Data Flow Analysis </B> <P>
  Barbara G. Ryder and Stephen J. Pendergrast,
  "Experiments in Optimizing FP",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume 14,
  Number 4,
  Pages 444-454,
  April,
  1988. <P>
   <a href="http://dx.doi.org/10.1109/32.4668">Digital Library</a> <p> 

  <LI>
  <B> Incremental Data Flow Analysis </B> <P>
  Martin Carroll and Barbara G. Ryder,
  "Incremental data flow analysis via dominator and attribute update",
  <I> Conference Record of the Fifteenth Annual ACM Symposium on Principles of Programming Languages, </I>
  Pages 274-284,
  January,
  1988. <P>

  <LI>
  <B> Incremental Data Flow Analysis </B> <P>
  B. G. Ryder and M. C. Paull,
  "Incremental data-flow analysis algorithms",
  <I> ACM Transactions on Programming Languages and Systems, </I>
  Volume 10,
  Number 1,
  Pages 1-50,
  January,
  1988. <P>
  <B> Note: </B> was DCS-TR-131. <P>

  <LI>
  <B> Incremental Data Flow Analysis </B> <P>
  B. G. Ryder, T.J. Marlowe, and M. C. Paull,
  "Conditions for Incremental Iteration: Examples and Counterexamples",
  <I> Science of Computer Programming, </I>
  Volume 11,
  Pages 1-15,
  1988. <P>
  <B> Note: </B> Also available as LCSR-TR-89. <P>

  <LI>
  <B> Incremental Data Flow Analysis </B> <P>
  B. G. Ryder,
  "An Application of Static Program Analysis to Software Maintenance",
  <I> Proceedings of the Twentieth Hawaii International Conference on System Sciences, Volume II, Software, </I>
  Pages 82-91,
  January,
  1987. <P>

  <LI>
  <B> Incremental Data Flow Analysis </B> <P>
  Martin Carroll and Barbara G. Ryder,
  "An Incremental Algorithm for Software Analysis",
  <I> Proceedings of the ACM SIGSOFT/SIGPLAN Software Engineering Symposium on Practical Software Development Environments, </I>
  Pages 171-179,
  December,
  1986. <P>

  <LI>
  <B> Foundations of Data Flow Analysis </B> <P>
  B. G. Ryder and M. C. Paull,
  "Elimination Algorithms for Data Flow Analysis",
  <I> ACM Computing Surveys, </I>
  Volume 18,
  Number 3,
  Pages 277-316,
  September,
  1986. <P>
  <B> See also: </B> DCS-TR-140. <P>

  <LI>
  <B> Incremental Data Flow Analysis </B> <P>
  Barbara G. Ryder,
  "Incremental Data Flow Analysis",
  <I> Conference Record of the Tenth Annual ACM Symposium on Principles of Programming Languages, </I>
  Pages 167-176,
  January,
  1983. <P>

  <LI>
  <B> Foundations of Data Flow Analysis </B> <P>
  A. M. Berman, M. C. Paull, and B. G. Ryder,
  "Proving Relative Lower Bounds for Incremental Algorithms",
  <I> Acta Informatica, </I>
  Volume 27,
  Pages 665-583,
  July,
  1990. <P>
  <B> See also: </B> DCS-TR-154 4/85. <P>
