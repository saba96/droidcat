  <LI>
  Ana Milanova, Atanas Rountev, and Barbara G. Ryder,
  "Precise Call Graphs for C Programs with Function Pointers",
  <I> Automated Software Engineering special issue on Source Code Analysis and Manipulation, </I>
  Volume 11,
  Number 1,
  Pages 7-26,
  January,
  2004. <P>
   <a href="http://dx.doi.org/10.1023/B:AUSE.0000008666.56394.a1">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2004  Kluwer Academic Publishers. <P>

  <LI>
  Ana Milanova, Atanas Rountev, and Barbara G. Ryder,
  "Precise Call Graph Construction in the Presence of Function Pointers",
  <I> Workshop on Source Code Analysis and Manipulation (SCAM 2002), </I>
  October,
  2002. <P>
   <a href="docs/scam02.ps">Local</a> <p> 
   <a href="http://dx.doi.org/10.1109/SCAM.2002.1134115">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2002 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  Ana Milanova, Atanas Rountev, and Barbara G. Ryder,
  "Precise Call Graph Construction in the Presence of Function Pointers",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-442,
  May,
  2001. <P>
   <a href="docs/dcs-tr-442.ps">Local</a> <p> 

  <LI>
  Atanas Rountev and Barbara G. Ryder,
  "Points-to and Side-effect Analyses for Programs Built with Precompiled Libraries",
  <I> Proceedings of the International Conference on Compiler Construction (CC 2001), </I>
  April,
  2001. <P>
   <a href="docs/cc01.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2001 <a href=http://www.springer.de/comp/lncs>Springer-Verlag</a>. Earlier version available as DCS-TR-423. <P>

  <LI>
  Barbara G. Ryder, William Landi, Philip A. Stocks, Sean Zhang, and Rita Altucher,
  "A schema for interprocedural modification side-effect analysis with pointer aliasing",
  <I> ACM Transactions on Programming Languages and Systems, </I>
  Volume 23,
  Pages 105-186,
  March,
  2001. <P>
   <a href="docs/toplas01.ps">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/383043.381532">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2001 <a href=http://www.acm.org/pubs/copyrights.html> ACM</a>. <P>

  <LI>
  Atanas Rountev and Barbara G. Ryder,
  "Points-to and Side-effect Analyses for Programs Built with Precompiled Libraries",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-423,
  October,
  2000. <P>
   <a href="docs/dcs-tr-423.ps.Z">Local</a> <p> 

  <LI>
  Atanas Rountev and Satish Chandra,
  "Off-line Variable Substitution for Scaling Points-to Analysis",
  <I> Proceedings of the Conference on Programming Language Design and Implementation (PLDI 2000), </I>
  June,
  2000. <P>
   <a href="docs/pldi00.ps">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/349299.349310">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2000 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. <P>

  <LI>
  Atanas Rountev and Barbara G. Ryder,
  "Practical Points-to Analysis for Programs Built with Libraries",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-410,
  February,
  2000. <P>
   <a href="docs/dcs-tr-410.ps.Z">Local</a> <p> 

  <LI>
  Atanas Rountev, Barbara G. Ryder, and William Landi,
  "Data-Flow Analysis of Program Fragments",
  <I> Proceedings of the 7th Symposium on the Foundations of Software Engineering (FSE'99), LNCS 1687, </I>
  September,
  1999. <P>
   <a href="docs/fse99.ps">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/318773.318945">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 1999 <a href=http://www.springer.de/comp/lncs>Springer-Verlag</a>. Earlier version available as DCS-TR-383. <P>

  <LI>
  Jyh-shiarn Yur,
  "Incremental Analysis for Flow- and Context-Sensitive Data-Flow Problems",
  <I> Rutgers University, Ph.D. Thesis, </I>
  July,
  1999. <P>
   <a href="docs/dcs-tr-393.ps.Z">Local</a> <p> 
  <B> Note: </B> Available as DCS-TR-393. <P>

  <LI>
  Atanas Rountev, Barbara G. Ryder, and William Landi,
  "Data-Flow Analysis of Program Fragments",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-383,
  March,
  1999. <P>
   <a href="docs/dcs-tr-383.ps.Z">Local</a> <p> 
  <B> Note: </B> Earlier version of the FSE'99 paper. <P>

  <LI>
  Xiang-Xiang Sean Zhang,
  "Practical Pointer Aliasing Analyses for C",
  <I> Rutgers University, Ph.D. Thesis, </I>
  August,
  1998. <P>
   <a href="docs/dcs-tr-367.ps.Z">Local</a> <p> 
  <B> Note: </B> Available as DCS-TR-367. <P>

  <LI>
  Sean Zhang, Barbara G. Ryder, and William Landi,
  "Experiments with Combined Analysis for Pointer Aliasing",
  <I> Proceedings of the Workshop on Program Analysis for Software Tools and Engineering (PASTE'98), </I>
  June,
  1998. <P>
   <a href="docs/dcs-tr-350.ps.Z">Local</a> <p> 
  <B> Note: </B> Also available as DCS-TR-350. <P>

  <LI>
  B. G. Ryder, W. Landi, P. Stocks, S. Zhang, and R. Altucher,
  "A Schema for Interprocedural Side Effect Analysis with Pointer Aliasing",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-336,
  May,
  1998. <P>
   <a href="docs/revision.pdf">Local</a> <p> 
  <B> Note: </B> Revised for journal August 1999. <P>

  <LI>
  P. Stocks, B. G. Ryder, W. Landi, and S. Zhang,
  "Comparing Flow and Context Sensitivity on the Modification-side-effects Problem",
  <I> Proceedings of the International Symposium on Software Testing and Analysis (ISSTA'98), </I>
  Pages 21-31,
  March,
  1998. <P>
   <a href="docs/dcs-tr-335.ps.Z">Local</a> <p> 
  <B> Note: </B> Also available as DCS-TR-335. <P>

  <LI>
  Sean Zhang, Barbara G. Ryder, and William Landi,
  "Program decomposition for pointer aliasing: a step toward practical analyses",
  <I> Proceedings of the 4th Symposium on the Foundations of Software Engineering (FSE'96), </I>
  October,
  1996. <P>
   <a href="docs/fse96.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 1996 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. Longer version available as LCSR-TR-259. <P>

  <LI>
  Sean Zhang, Barbara G. Ryder, and William Landi,
  "Program Decomposition for Pointer-induced Aliasing Analysis",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-259,
  March,
  1996. <P>
   <a href="docs/lcsr-tr-259.ps.Z">Local</a> <p> 
  <B> Note: </B> Longer version of the FSE'96 paper. <P>

  <LI>
  A. Shah and B. G. Ryder,
  "Function Pointers in C -- An Empirical Study",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-244,
  May,
  1995. <P>
   <a href="docs/lcsr-tr-244.ps.Z">Local</a> <p> 

  <LI>
  S. Zhang and B. G. Ryder,
  "Complexity of Single Level Function Pointer Aliasing Analysis",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-233,
  October,
  1994. <P>
   <a href="docs/lcsr-tr-233.ps.Z">Local</a> <p> 

  <LI>
  H. Pande, W. Landi, and B. G. Ryder,
  "Interprocedural Def-Use Associations for C Systems with Single Level Pointers",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume 20,
  Number 5,
  Pages 385-403,
  May,
  1994. <P>
  <B> Note: </B> Earlier version available as LCSR-TR-193. <P>

  <LI>
  T. J. Marlowe, W. Landi, B. G. Ryder, J. Choi, M. Burke, and P. Carini,
  "Pointer-induced Aliasing: A Clarification",
  <I> ACM SIGPLAN Notices, </I>
  Volume 28,
  Number 9,
  Pages 67-70,
  September,
  1993. <P>

  <LI>
  W. Landi, B. G. Ryder, and S. Zhang,
  "Interprocedural Modification Side Effect Analysis With Pointer Aliasing",
  <I> Proceedings of the SIGPLAN '93 Conference on Programming Language Design and Implementation, </I>
  Pages 56-67,
  June,
  1993. <P>
  <B> See also: </B> LCSR-TR-201, LCSR-TR-195. <P>

  <LI>
  W. Landi, B. G. Ryder, and S. Zhang,
  "Interprocedural Modification Side Effect Analysis With Pointer Aliasing",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-201,
  March,
  1993. <P>
   <a href="docs/lcsr-tr-201.ps.Z">Local</a> <p> 
  <B> Note: </B> This report supersedes LCSR-TR-195 and is an expansion of the ACM SIGPLAN PLDI'93 paper. <P>

  <LI>
  W. Landi and B. G. Ryder,
  "A Safe Approximate Algorithm for Interprocedural Pointer Aliasing",
  <I> Proceedings of the SIGPLAN '92 Conference on Programming Language Design and Implementation, </I>
  Pages 235-248,
  June,
  1992. <P>
  <B> See also: </B> LCSR-TR-168. <P>

  <LI>
  William A. Landi,
  "Interprocedural Aliasing in the Presence of Pointers",
  <I> Rutgers University, Ph.D. Thesis, </I>
  January,
  1992. <P>
   <a href="docs/lcsr-tr-174.ps.Z">Local</a> <p> 
  <B> Note: </B> Also available as LCSR-TR-174. <P>

  <LI>
  H. Pande, B. G. Ryder, and W. Landi,
  "Interprocedural Def-Use Associations for C Programs",
  <I> Proceedings of the ACM SIGSOFT Conference on Testing, Analysis and Verification, </I>
  Pages 139-153,
  October,
  1991. <P>

  <LI>
  ,
  "",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-168,
  September,
  1991. <P>
   <a href="docs/lcsr-tr-168.ps.Z">Local</a> <p> 
  <B> Note: </B> a fuller version of PLDI'92 paper. <P>

  <LI>
  H. Pande, B. G. Ryder, and W. Landi,
  "Interprocedural Def-Use Associations in C Programs",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-162,
  April,
  1991. <P>

  <LI>
  W. Landi and B. G. Ryder,
  "Pointer-induced Aliasing: A Problem Classification",
  <I> Conference Record of the Eighteenth Annual ACM Symposium on Principles of Programming Languages, </I>
  Pages 93-103,
  January,
  1991. <P>

