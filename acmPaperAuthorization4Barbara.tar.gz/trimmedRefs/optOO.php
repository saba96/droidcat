  <LI>
  Marc Fisher II and Luke Marrs and Barbara G. Ryder,
  "Hi-C: Diagnosing Object Churn in Framework-Based Applications",
  <I> Proceedings of the Symposium on the Foundations of Software Engineering - Demo Abstract, </I>
  November,
  2010. <P>
   <a href="docs/fse10-demo-bookmarks.pdf">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2010 <a href=http://www.acm.org/pubs/copyrights.html> ACM</a>. <P>

  <LI>
  Jan Wloka and Einar W. H&oslash;st and Barbara G. Ryder,
  "Tool Support for Change-centric Test Development",
  <I> IEEE Software, </I>
  Volume 27,
  Number 3,
  May/June,
  2010. <P>
   <a href="docs/software10.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1109/MS.2009.159">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2010 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  Ali H. Ibrahim and William R. Cook and Marc Fisher II and Eli Tilevich,
  "Remote batch invocation for web services: Document-oriented web services with object-oriented interfaces",
  <I> Proceedings of the European Conference on Web Services, </I>
  Pages {190-199},
  November,
  2009. <P>
   <a href="docs/ibrahim-ecows09.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1109/ECOWS.2009.16">Digital Library</a> <p> 

  <LI>
  Jan Wloka and Barbara G. Ryder and Frank Tip,
  "JUnitMX -- A Change-aware Unit Testing Tool",
  <I> International Conference on Software Engineering, </I>
  May,
  2009. <P>
   <a href="docs/icse09-demo.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1109/ICSE.2009.5070557">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2009 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  Jan Wloka and Barbara G. Ryder and Frank Tip and Xiaoxia Ren,
  "Safe-Commit Analysis to Facilitate Team Software Development",
  <I> International Conference on Software Engineering, </I>
  May,
  2009. <P>
   <a href="docs/icse09-committable.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1109/ICSE.2009.5070549">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2009 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  Xiaoxia Ren and Barbara G. Ryder,
  "Heuristic Ranking of Java Program Edits for Fault Localization",
  <I> Proceedings of the 2007 ACM SIGSOFT international symposium on Software testing and analysis(ISSTA 2007), </I>
  July,
  2007. <P>
   <a href="http://dx.doi.org/10.1145/1273463.1273495">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2007 <a href=http://www.acm.org/pubs/copyrights.html> ACM</a>. <P>

  <LI>
  Maximilian Stoerzer and Barbara G. Ryder and Xiaoxia Ren and Frank Tip,
  "Finding Failure-Inducing Changes in Java Programs using Change Classification",
  <I> Proceedings of the 14th SIGSOFT Conference on the Foundations of Software Engineering, </I>
  November,
  2006. <P>
   <a href="http://dx.doi.org/10.1145/1181775.1181783">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2006 <a href=http://www.acm.org/pubs/copyrights.html> ACM</a>.. <P>

  <LI>
  Xiaoxia Ren and Ophelia C. Chesley and Barbara G. Ryder,
  "Identifying Failure Causes in Java Programs: an Application of Change Impact Analysis",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume 32,
  Pages 718-732,
  September,
  2006. <P>
   <a href="http://dx.doi.org/10.1109/TSE.2006.90">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2006 <a href=http://www.ieee.org/portal/index.jsp?pageID=corp_level1&path=about/documentation/copyright&file=index.xml&xsl=generic.xsl>IEEE</a>. <P>

  <LI>
  Ophelia Chesley, Xiaoxia Ren, Barbara G. Ryder,
  "Crisp: A Debugging Tool for Java Programs",
  <I> Proceedings of the 21st International Conference on Software Maintenance(ICSM 2005), </I>
  September,
  2005. <P>
   <a href="http://dx.doi.org/10.1109/ICSM.2005.37">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2005 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  Maximilian Stoerzer and Barbara G. Ryder and Xiaoxia Ren and Frank Tip,
  "Finding Failure-Inducing Changes using Change Classification",
  Number DCS-TR-582,
  September,
  2005. <P>
   <a href="docs/dcs-tr-582.pdf">Local</a> <p> 

  <LI>
  Xiaoxia Ren, Fenil Shah, Frank Tip, Barbara G. Ryder, Ophelia Chesley,
  "Chianti: A Tool for Change Impact Analysis of Java Programs",
  <I> Proceedings of the 19th annual ACM SIGPLAN Conference on Object-oriented programming, systems, languages, and applications(OOPSLA 2004), </I>
  Pages 432-448,
  October,
  2004. <P>
   <a href="docs/oopsla04.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/1035292.1029012">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2004 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. Also available as DCS-TR-551.. <P>

  <LI>
  Xiaoxia Ren, Fenil Shah, Frank Tip, Barbara G. Ryder, Ophelia Chesley and Julian Dolby,
  "Chianti: A Prototype Change Impact Analysis Tool for Java",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-533,
  September,
  2003. <P>
   <a href="docs/dcs-tr-533.ps.Z">Local</a> <p> 
  <B> Note: </B> Also available as IBM RC-22983. <P>

  <LI>
  Matthew Arnold, Michael Hind, and Barbara G. Ryder,
  "Online Feedback-Directed Optimization of Java",
  <I> Proceedings of the 17th ACM SIGPLAN Conference on Object-Oriented Programming, Systems, Languages and Applications (OOPSLA 2002), </I>
  Pages 111-129,
  November,
  2002. <P>
   <a href="docs/oopsla02.ps">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/582419.582432">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2002 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. <P>

  <LI>
  Matthew Arnold,
  "Online Instrumentation and Feedback Directed Optimization of Java",
  <I> Rutgers University, Ph.D. Thesis, </I>
  October,
  2002. <P>
   <a href="docs/dcs-tr-469.ps.Z">Local</a> <p> 
  <B> Note: </B> Also available as DCS-TR-469. <P>

  <LI>
  Matthew Arnold and Barbara G. Ryder,
  "Thin Guards: A Simple and Effective Technique for Reducing the Penalty of Dynamic Class Loading",
  <I> Proceedings of the European Conference on Object-Oriented Programming (ECOOP 2002), </I>
  June,
  2002. <P>
   <a href="docs/ecoop02.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2002 <a href=http://www.springer.de/comp/lncs>Springer-Verlag</a>. <P>

  <LI>
  Matthew Arnold,
  "Online Instrumentation and Feedback-Directed Optimization of Java",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-469,
  November,
  2001. <P>
   <a href="docs/dcs-tr-469.ps">Local</a> <p> 

  <LI>
  Matthew Arnold and Barbara G. Ryder,
  "Thin Guards: A Simple and Effective Technique for Reducing the Penalty of Dynamic Class Loading",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-470,
  November,
  2001. <P>
   <a href="docs/dcs-tr-470.ps">Local</a> <p> 

  <LI>
  Matthew Arnold and Barbara G. Ryder,
  "A Framework for Reducing the Cost of Instrumented Code",
  <I> Proceedings of the Conference on Programming Language Design and Implementation (PLDI 2001), </I>
  Pages 168-179,
  June,
  2001. <P>
   <a href="docs/pldi01.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2001 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. Earlier version available as DCS-TR-424. <P>

  <LI>
  Barbara G. Ryder and Frank Tip,
  "Change Impact Analysis for Object-Oriented Programs",
  <I> Proceedings of the Workshop on Program Analysis for Software Tools and Engineering (PASTE 2001), </I>
  Pages 46-53,
  June,
  2001. <P>
   <a href="docs/paste01.pdf">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2001 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. Also available as IBM T.J.Watson Reseach Center Technical Report RC21997. <P>

  <LI>
  Atanas Rountev, Ana Milanova, and Barbara G. Ryder,
  "Class Analysis for Testing of Polymorphism in Java Software",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-432,
  February,
  2001. <P>
   <a href="docs/dcs-tr-432.ps.Z">Local</a> <p> 

  <LI>
  Matthew Arnold, Michael Hsiao, Ulrich Kremer, and Barbara G. Ryder,
  "Exploring the Interaction between Java's Implicitly Thrown Exceptions and Instruction Scheduling",
  <I> International Journal of Parallel Programming, special issue, </I>
  Volume 29,
  Pages 111-137,
  2001. <P>
   <a href="http://dx.doi.org/10.1023/A:1007621602134">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2001  Kluwer Academic Publishers. <P>

  <LI>
  Matthew Arnold and Barbara G. Ryder,
  "A Framework for Reducing the Cost of Instrumented Code",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-424,
  November,
  2000. <P>
   <a href="docs/dcs-tr-424.ps.Z">Local</a> <p> 

  <LI>
  Matthew Arnold, Stephen Fink, David Grove, Michael Hind, and Peter Sweeney,
  "Adaptive Optimization in the Jalapeno JVM",
  <I> Proceedings of the Conference on Object-Oriented Programming, Systems, Languages and Applications (OOPSLA 2000), </I>
  October,
  2000. <P>
   <a href="docs/oopsla00.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/353171.353175">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2000 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. <P>

  <LI>
  Matthew Arnold, Michael Hind, and Barbara G. Ryder,
  "An Empirical Study of Selective Optimization",
  <I> Proceedings of the International Workshop on Languages and Compilers for Parallel Computing (LCPC 2000), </I>
  August,
  2000. <P>
   <a href="docs/lcpc00.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2000 <a href=http://www.springer.de/comp/lncs>Springer-Verlag</a>. <P>

  <LI>
  Matthew Arnold, Michael Hind, and Barbara G. Ryder,
  "An Empirical Study of Selective Optimization",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-411,
  March,
  2000. <P>
   <a href="docs/dcs-tr-411.ps.Z">Local</a> <p> 

  <LI>
  Matthew Arnold, Michael Hsiao, Ulrich Kremer, and Barbara G. Ryder,
  "Instruction Scheduling in the Presence of Java's Runtime Exceptions",
  <I> Proceedings of the 12th Workshop on Languages and Compilers for Parallel Computing (LCPC'99), </I>
  August,
  1999. <P>
  <B> Note: </B> &copy Copyright 2000 <a href=http://www.springer.de/comp/lncs>Springer-Verlag</a>. Earlier version available as DCS-TR-403. <P>

  <LI>
  Matthew Arnold, Michael Hsiao, Ulrich Kremer, and Barbara G. Ryder,
  "Instruction Scheduling in the Presence of Java's Runtime Exceptions",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-384,
  June,
  1999. <P>
   <a href="docs/dcs-tr-384.ps.Z">Local</a> <p> 
  <B> Note: </B> Earlier version of the LCPC'99 paper. <P>

