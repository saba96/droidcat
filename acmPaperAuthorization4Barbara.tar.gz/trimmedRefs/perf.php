  <LI>
  Chung-Hsing Hsu and Ulrich Kremer,
  "A Stable and Efficient Loop Tiling Algorithm",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-407,
  December,
  1999. <P>
   <a href="docs/dcs-tr-407.ps.Z">Local</a> <p> 

  <LI>
  Chung-Hsing Hsu and Ulrich Kremer,
  "Tile Selection Algorithms and Their Performance Models",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-401,
  October,
  1999. <P>
   <a href="docs/dcs-tr-401.ps.Z">Local</a> <p> 

  <LI>
  Chung-Hsing Hsu and Ulrich Kremer,
  "IPERF: A Framework for Automatic Construction of Performance Prediction Models",
  <I> First Workshop on Profile and Feedback-Directed Compilation, </I>
  October,
  1998. <P>
   <a href="docs/PFDC98.ps">Local</a> <p> 

  <LI>
  Chung-Hsing Hsu and Ulrich Kremer,
  "A Framework for Qualitative Performance Prediction",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-363,
  July,
  1998. <P>
   <a href="docs/dcs-tr-363.ps.Z">Local</a> <p> 

