  <LI>
  Shiyi Wei, Franceska Xhakaj, and Barbara G. Ryder,
  "Empirical Study of the Dynamic Behavior of JavaScript Objects",
  <I> Software: Practice and Experience, </I>
  May,
  2015. <P>
   <a href="docs/wei15spe.pdf">Local</a> <p>
   <a href="http://onlinelibrary.wiley.com/doi/10.1002/spe.2334/abstract">Digital Library</a> <p>
  <B> Note: </B> &copy Copyright 2015 <a href="http://www.wiley.com/WileyCDA/Section/id-301464.html"> Wiley</a>. <P>

  <LI>
  Shiyi Wei and Barbara G. Ryder,
  "Adaptive Context-sensitive Analysis for JavaScript",
  <I> Proceedings of the European Conference on Object-oriented Programming (ECOOP), </I>
  July,
  2015. <P>
   <a href="docs/weiryder-ecoop15.pdf">Local</a> <p>
   <a href="http://drops.dagstuhl.de/opus/volltexte/2015/5244/">Digital Library</a> <p>
  <B> Note: </B> &copy Copyright 2015 <a href="http://drops.dagstuhl.de/doku/urheberrecht1.html"> Dagstuhl</a>. <P>

  <LI>
  Shiyi Wei and Barbara G. Ryder,
  "State-sensitive Points-to Analysis for the Dynamic Behavior of JavaScript Objects",
  <I> Proceedings of the European Conference on Object-oriented Programming (ECOOP), </I>
  July,
  2014. <P>
   <a href="docs/weiryder-ecoop14.pdf">Local</a> <p>
   <a href="http://link.springer.com/chapter/10.1007%2F978-3-662-44202-9_1">Digital Library</a> <p>
  <B> Note: </B> &copy Copyright 2014 <a href=http://www.springer.com/authors/book+authors/helpdesk?SGWID=0-1723113-12-799504-0> Springer</a>. <P>

  <LI>
  Shiyi Wei and Barbara G. Ryder,
  "Practical Blended Taint Analysis for JavaScript",
  <I> Proceedings of the 2013 ACM SIGSOFT international symposium on Software testing and analysis(ISSTA 2013), </I>
  July,
  2013. <P>
   <a href="docs/weiryder-issta13.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/2483760.2483788">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2013 <a href=http://www.acm.org/pubs/copyrights.html> ACM</a>. <P>

  <LI>
  Shiyi Wei and Barbara G. Ryder,
  "A Practical Blended Analysis for Dynamic Features in JavaScript",
  Number Department of Computer Science, Virginia Tech, TR-12-18,
  September,
  2012. <P>
   <a href="http://eprints.cs.vt.edu/archive/00001206/">Local</a> <p> 

  <LI>
  Marc Fisher II and Bruno Dufour and Shrutarshi Basu and Barbara G. Ryder,
  "Exploring the Impact of Context Sensitivity on Blended Analysis",
  <I> Proceedings of the International Conference on Software Maintenance, </I>
  September,
  2010. <P>
   <a href="docs/icsm2010-bookmarks.pdf">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2010 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  Emmanuel Geay and Marco Pistoia and Takaaki Tateishi and Barbara G. Ryder and Julian Dolby,
  "Modular String-Sensitive Permission Analysis with Demand-Driven Precision",
  <I> International Conference on Software Engineering, </I>
  May,
  2009. <P>
   <a href="docs/icse09-permissions.pdf">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2009 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  Bruno Dufour and Barbara G. Ryder and Gary Sevitsky,
  "A Scalable Technique for Characterizing the Usage of Temporaries in Framework-Intensive Java Applications",
  <I> Proceedings of the 16th SIGSOFT Conference on the Foundations of Software Engineering, </I>
  November,
  2008. <P>
   <a href="docs/p59-dufour.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/1453101.1453111">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2008 <a href=http://www.acm.org/pubs/copyrights.html> ACM</a>. <P>

  <LI>
  Weilei Zhang and Barbara G. Ryder,
  "Automatic construction of accurate application call graph with library call abstraction for java",
  <I> Journal of Software Maintenance and Evolution: Research and Practice, </I>
  Volume 19,
  Number 4,
  Pages 231-252,
  August,
  2007. <P>
   <a href="http://dx.doi.org/10.1002/smr.351">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2007 <a href=http://www.wiley.com/go/copyright> John Wiley & Sons </a>. <P>

  <LI>
  Bruno Dufour and Barbara G. Ryder and Gary Sevitsky,
  "Blended Analysis for Performance Understanding of Framework-based Applications",
  <I> Proceedings of the 2007 ACM SIGSOFT international symposium on Software testing and analysis(ISSTA 2007), </I>
  July,
  2007. <P>
   <a href="docs/dufour-issta07.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1145/1273463.1273480">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2007 <a href=http://www.acm.org/pubs/copyrights.html> ACM</a>. <P>

  <LI>
  Weilei Zhang and Barbara G. Ryder,
  "Discovering accurate interclass test dependences",
  <I> Proceedings of the Workshop on Program Analysis for Software Tools and Engineering (PASTE 2007), </I>
  Pages 55-62,
  June,
  2007. <P>
   <a href="http://dx.doi.org/10.1145/1251535.1251545">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2007 <a href=http://www.acm.org/pubs/copyrights.html> ACM </a>. <P>

  <LI>
  Chen Fu and Barbara G. Ryder,
  "Exception-Chain Analysis: Revealing Exception Handling Architecture in Java Server Applications",
  <I> icse, </I>
  May,
  2007. <P>
   <a href="http://dx.doi.org/10.1109/ICSE.2007.35">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2007 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  Weilei Zhang and Barbara G. Ryder,
  "Constructing Accurate Application Call Graphs for Java to Model Library Callbacks",
  <I> Proceedings of the 6th International Workshop on Source Code Analysis and Manipulation, </I>
  September,
  2006. <P>
   <a href="docs/scam2006.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1109/SCAM.2006.9">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2006 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  Chen Fu and Barbara G. Ryder,
  "Exception-chain Analysis: Revealing Exception Handling Architecture in Java Server Applications",
  Number DCS-TR-599,
  March,
  2006. <P>
   <a href="docs/ecchain.pdf">Local</a> <p> 

  <LI>
  Weilei Zhang and Barbara G. Ryder,
  "A Semantics-Based Definition  for Interclass Test Dependence",
  Number DCS-TR-597,
  January,
  2006. <P>
   <a href="docs/dcs-tr-597.pdf">Local</a> <p> 

  <LI>
  Ana Milanova and Barbara G. Ryder,
  "Annotated Inclusion Constraints for Precise Flow Analysis",
  <I> Proceedings of the 21st International Conference on Software Maintenance(ICSM 2005), </I>
  September,
  2005. <P>
   <a href="http://dx.doi.org/10.1109/ICSM.2005.24">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2005 <a href=http://www.computer.org/portal/site/ieeecs/menuitem.c5efb9b8ade9096b8a9ca0108bcd45f3/index.jsp?&pName=ieeecs_level1&path=ieeecs/content&file=copyright.xml&xsl=generic.xsl&;jsessionid=GGnxJL4mRQxqY6Xp1fcLLhGnXtwjQLMT1mb6RytP0BStYqDYJmTQ!-950687913> IEEE Computer Society </a>. <P>

  <LI>
  Chen Fu and Barbara G. Ryder,
  "Testing and Understanding Error Recovery Code in Java Applications",
  Number DCS-TR-579,
  July,
  2005. <P>
   <a href="docs/dcs-tr-579.ps.Z">Local</a> <p> 
  <B> Note: </B> ECOOP 2005 Workshop on Exception Handling in Object Oriented Systems: Developing Systems that Handle Exceptions. <P>

  <LI>
  Weilei Zhang and Barbara G. Ryder,
  "A Practical Algorithm for Interclass Testing Dependence",
  Number DCS-TR-574,
  April,
  2005. <P>
   <a href="ftp://ftp.cs.rutgers.edu/pub/technical-reports/dcs-tr-574.ps.Z">Local</a> <p> 

  <LI>
  Chen Fu, Ana Milanova, Barbara G. Ryder, David Wonnacott,
  "Robustness Testing of Java Server Applications",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume 31,
  Number 4,
  Pages 292-312,
  April,
  2005. <P>
   <a href="http://dx.doi.org/10.1109/TSE.2005.51">Digital Library</a> <p> 
  <B> Note: </B> Extended version of ISSTA 2004 paper solicited for journal publication.. <P>

  <LI>
  Ana Milanova, Atanas Rountev, Barbara G. Ryder,
  "Parameterized object sensitivity for points-to analysis for Java",
  <I> ACM Transactions on Software Engineering Methodology, </I>
  Volume 14,
  Number 1,
  Pages 1-41,
  January,
  2005. <P>
   <a href="http://dx.doi.org/10.1145/1044834.1044835">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2004 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. Extended version of ISSTA 2002 paper solicited for journal publication.. <P>

  <LI>
  Chen Fu, Barbara Ryder, Ana Milanova, David Wonnacott,
  "Testing of Java Web Services for Robustness",
  <I> Proceedings of the 2004 ACM SIGSOFT international symposium on Software testing and analysis(ISSTA 2004), </I>
  Pages 23-33,
  July,
  2004. <P>
   <a href="http://dx.doi.org/10.1145/1013886.1007516">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2004 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>.   Solicited for submission to special issue of IEEE Transactions on Software Engineering. <P>

  <LI>
  Atanas Rountev, Ana Milanova and Barbara G. Ryder,
  "Fragment Class Analysis for Testing Polymorphism in Java Software",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume 30,
  Number 6,
  Pages 372-387,
  June,
  2004. <P>
   <a href="http://dx.doi.org/10.1109/TSE.2004.20">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2004 <a href=http://www.ieee.org/portal/index.jsp?pageID=corp_level1&path=about/documentation/copyright&file=index.xml&xsl=generic.xsl>IEEE</a>, Extended version of ICSE 2003 paper solicited for special issue journal publication.. <P>

  <LI>
  Ana Milanova,
  "Precise and Practical Flow Analysis of Object-Oriented Software",
  <I> Rutgers University, Ph.D. Thesis, </I>
  August,
  2003. <P>
   <a href="docs/dcs-tr-539.ps.Z">Local</a> <p> 
  <B> Note: </B> Also available as DCS-TR-539. <P>

  <LI>
  Chen Fu, Richard P. Martin, Kiran Nagaraja, Thu D. Nguyen, Barbara G. Ryder, and David G. Wonnacott,
  "Compiler Directed Program-fault Coverage for Highly Available Java Internet Services",
  <I> 2003 International Conference on Dependable Systems and Networks (DSN 2003), </I>
  Pages 595-604,
  June,
  2003. <P>
   <a href="docs/dsn03.pdf">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2003 <a href=http://www.ieee.org/portal/index.jsp?pageID=corp_level1&path=about/documentation/copyright&file=index.xml&xsl=generic.xsl>IEEE</a>. <P>

  <LI>
  Atanas Rountev, Ana Milanova, and Barbara G. Ryder,
  "Fragment Class Analysis for Testing of Polymorphism in Java Software",
  <I> Proceedings of the 25th International Conference on Software Engineering (ICSE 2003), </I>
  Pages 210-220,
  May,
  2003. <P>
   <a href="docs/icse03.pdf">Local</a> <p> 
   <a href="http://dx.doi.org/10.1109/ICSE.2003.1201201">Digital Library</a> <p> 
  <B> Note: </B> &copy Copyright 2003 <a href=http://www.ieee.org/portal/index.jsp?pageID=corp_level1&path=about/documentation/copyright&file=index.xml&xsl=generic.xsl>IEEE</a>. <P>

  <LI>
  B. G. Ryder,
  "Dimensions of Precision in Reference Analysis of Object-oriented Programming Languages",
  <I> Proceedings of the International Conference on Compiler Construction, </I>
  Pages 126-137,
  April,
  2003. <P>
   <a href="docs/cc03.pdf">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2003 <a href=http://www.springer.de/comp/lncs/>Springer-Verlag</a>. <P>

  <LI>
  Ana Milanova, Atanas Rountev, and Barbara G. Ryder,
  "Constructing Precise Object Relation Diagrams",
  <I> Proceedings of International Conference on Software Maintenance (ICSM 2002), </I>
  October,
  2002. <P>
   <a href="docs/icsm02.ps">Local</a> <p> 

  <LI>
  Atanas Rountev,
  "Dataflow Analysis of Software Fragments",
  <I> Rutgers University, Ph.D. Thesis, </I>
  August,
  2002. <P>
  <B> Note: </B> Also available as DCS-TR-501. <P>

  <LI>
  Ana Milanova, Atanas Rountev, and Barbara G. Ryder,
  "Parameterized Object Sensitivity for Points-to and Side-Effect Analyses for Java",
  <I> Proceedings of the International Symposium on Software Testing and Analysis (ISSTA 2002), </I>
  July,
  2002. <P>
   <a href="docs/issta02.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2001 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. <P>

  <LI>
  Ana Milanova, Atanas Rountev, and Barbara G. Ryder,
  "Constructing Precise Object Relation Diagrams",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-482,
  March,
  2002. <P>
   <a href="docs/dcs-tr-482.ps">Local</a> <p> 

  <LI>
  Atanas Rountev, Ana Milanova, and Barbara G. Ryder,
  "Points-to Analysis for Java Using Annotated Constraints",
  <I> Proceedings of the Conference on Object-Oriented Programming, Systems, Languages and Applications (OOPSLA 2001), </I>
  October,
  2001. <P>
   <a href="docs/oopsla01.pdf">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2001 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. <P>

  <LI>
  Ramkrishna Chatterjee, Barbara G. Ryder, and William Landi,
  "Complexity of Points-to Analysis of Java in the Presence of Exceptions",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume 27,
  Number 6,
  Pages 481-512,
  June,
  2001. <P>
   <a href="docs/tse01.ps">Local</a> <p> 
  <B> Note: </B> The URL points to a preliminary version. <P>

  <LI>
  Ramkrishna Chatterjee and Barbara G. Ryder,
  "Data-flow-based Testing of Object-Oriented Libraries",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-433,
  April,
  2001. <P>
   <a href="docs/dcs-tr-433.ps">Local</a> <p> 
  <B> Note: </B> Earlier version available as DCS-TR-382. <P>

  <LI>
  Atanas Rountev, Ana Milanova, and Barbara G. Ryder,
  "Points-to Analysis for Java Based on Annotated Constraints",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-428,
  November,
  2000. <P>
   <a href="docs/dcs-tr-428.ps.Z">Local</a> <p> 
  <B> Note: </B> Supersedes DCS-TR-417. <P>

  <LI>
  Atanas Rountev, Ana Milanova, and Barbara G. Ryder,
  " Points-to Analysis for Java Using Annotated Inclusion Constraints",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-417,
  July,
  2000. <P>
   <a href="docs/dcs-tr-417.ps.Z">Local</a> <p> 

  <LI>
  Barbara G. Ryder, Donald Smith, Ulrich Kremer, Michael Gordon, and Nirav Shah,
  "A Static Study of Java Exceptions",
  <I> Proceedings of the 9th International Conference on Compiler Construction (CC 2000), </I>
  March,
  2000. <P>
   <a href="docs/cc00.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2000 <a href=http://www.springer.de/comp/lncs>Springer-Verlag</a>. Earlier version available as DCS-TR-403. <P>

  <LI>
  Ramkrishna Chatterjee,
  "Modular Data-flow Analysis of Statically Typed Object-Oriented Programming Languages",
  <I> Rutgers University, Ph.D. Thesis, </I>
  October,
  1999. <P>
   <a href="docs/dcs-tr-406.ps.Z">Local</a> <p> 
  <B> Note: </B> Available as DCS-TR-406. <P>

  <LI>
  Barbara G. Ryder, Donald Smith, Ulrich Kremer, Michael Gordon, and Nirav Shah,
  "A Static Study of Java Exceptions using JESP",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-403,
  October,
  1999. <P>
   <a href="docs/dcs-tr-403.ps.Z">Local</a> <p> 

  <LI>
  Ramkrishna Chatterjee and Barbara G. Ryder,
  "Data-flow-based Testing of Object-Oriented Libraries",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-382,
  March,
  1999. <P>
   <a href="docs/dcs-tr-382.ps.Z">Local</a> <p> 

  <LI>
  R. Chatterjee, B. G. Ryder, and W. Landi,
  "Relevant Context Inference",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-360,
  January,
  1999. <P>
   <a href="docs/dcs-tr-360.ps.Z">Local</a> <p> 
  <B> Note: </B> Longer version of the POPL'99 paper - more on exceptions, libraries, and testing. <P>

  <LI>
  Ramkrishna Chatterjee, Barbara G. Ryder, and William Landi,
  "Relevant Context Inference",
  <I> Proceedings of the 26th ACM SIGACT/SIGPLAN Symposium on Principles of Programming Languages (POPL'99), </I>
  January,
  1999. <P>
   <a href="docs/popl99.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 1999 <a href=http://www.acm.org/pubs/copyrights.html>ACM</a>. Longer version available as DCS-TR-360. <P>

  <LI>
  Ramkrishna Chatterjee, Barbara G. Ryder, and William Landi,
  "Complexity of Concrete Type-Inference in the Presence of Exceptions",
  <I> Proceedings of the European Symposium on Programming (ESOP'98), LNCS 1381, </I>
  April,
  1998. <P>
   <a href="docs/esop98.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 1998 <a href=http://www.springer.de/comp/lncs>Springer-Verlag</a>. Longer version available as DCS-TR-341. <P>

  <LI>
  R. Chatterjee and B. G Ryder,
  "Modular Concrete Type-Inference for Statically Typed Object-Oriented Programming Languages",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-349,
  November,
  1997. <P>
   <a href="docs/dcs-tr-349.ps.Z">Local</a> <p> 

  <LI>
  R. Chatterjee, B. G. Ryder, and W. Landi,
  "Complexity of Concrete Type-Inference in the Presence of Exceptions",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-341,
  September,
  1997. <P>
   <a href="docs/dcs-tr-341.ps.Z">Local</a> <p> 
  <B> Note: </B> Longer version of the ESOP'98 paper. <P>

  <LI>
  R. Chatterjee and B. G. Ryder,
  "Scalable, Flow-Sensitive Type-Inference for Statically Typed Object-Oriented Programming Languages",
  <I> Department of Computer Science, Rutgers University, </I>
  Number DCS-TR-326,
  July,
  1997. <P>
   <a href="docs/dcs-tr-326.ps.Z">Local</a> <p> 

  <LI>
  Hemant Pande and Barbara G. Ryder,
  "Data-flow-based Virtual Function Resolution",
  <I> Static Analysis: Third International Symposium (SAS'96), LNCS 1145, </I>
  Pages 238-254,
  September,
  1996. <P>
   <a href="docs/sas96.ps">Local</a> <p> 
  <B> Note: </B> &copy Copyright 1996  <a href=http://www.springer.de/comp/lncs>Springer-Verlag</a>. <P>

  <LI>
  Hemant D. Pande,
  "Compile Time Analysis of C and C++ Systems",
  <I> Rutgers University, Ph.D. Thesis, </I>
  May,
  1996. <P>
   <a href="docs/lcsr-tr-260.ps.Z">Local</a> <p> 
  <B> Note: </B> Available as LCSR-TR-260. <P>

  <LI>
  Hemant Pande and Barbara G. Ryder,
  "Static Type Determination and Aliasing for C++",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-250-A,
  October,
  1995. <P>
   <a href="docs/lcsr-tr-250-a.ps.Z">Local</a> <p> 

  <LI>
  H. Pande and B. G. Ryder,
  "Static Type Determination and Aliasing for C++",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-236,
  December,
  1994. <P>
   <a href="docs/lcsr-tr-236.ps.Z">Local</a> <p> 

  <LI>
  H. Pande and B. G. Ryder,
  "Static Type Determination for C++",
  <I> Proceedings of the Sixth USENIX C++ Technical Conference, </I>
  Pages 85-97,
  April,
  1994. <P>

