  <LI>
  Xiaokui Shu, Danfeng Yao, and Barbara Ryder,
  "A Formal Framework for Program Anomaly Detection", 
  <I> Proceedings of the 18th International Symposium on Research in Attacks, Intrusions and Defenses (RAID), </I>
  Nov,
  2015. <P>
   <a href="docs/RAID-2015-Yao.pdf">Local</a> <p>
   <a href="http://link.springer.com/chapter/10.1007%2F978-3-319-26362-5_13">Digital Library</a> <p>
  <B> Note: </B> &copy Copyright 2015 <a href=http://www.springer.com/authors/book+authors/helpdesk?SGWID=0-1723113-12-799504-0> Springer</a>. <P>

  <LI>
  Kui Xu and Danfeng Yao and Barbara G. Ryder and Ke Tian,
  "Probabilistic Program Modeling for High Precision Anomaly Classification",
  <I> Proceedings of the Computer Security Foundations Symposium, </I>
  July,
  2015. <P>
   <a href="docs/HMM-CSF-15-Yao.pdf">Local</a> <p>
   <a href="http://ieeexplore.ieee.org/xpl/articleDetails.jsp?reload=true&arnumber=7243750">Digital Library</a> <p>
  <B> Note: </B> &copy Copyright 2015 <a href="https://www.computer.org/web/publications/copyright"> IEEE Computer Society</a>. <P>

  <LI>
  Karim O. Elish and Danfeng Yao and Barbara G. Ryder,
  "Static Characterization of Pairwise Android Inter-component Communications for Collusion Detection",
  <I> Proceedings of the Mobile Security Technologies (MoST), </I>
  May,
  2015. <P>

  <!--<LI>
  <B> Security </B> <P>
  Karim O. Elish and Danfeng Yao and Barbara G. Ryder,
  "Profiling User-trigger Dependence for Android Malware Detection",
  <I> Computers and Society, </I>
  February,
  2015. <P>-->

  <LI>
  Karim O. Elish, Xiaokui Shu, Danfeng Yao, Barbara Ryder, and Xuxian Jiang. 
  "Profiling User-trigger Dependence for Android Malware Detection",
  <I> Computers & Security (C&S), </I>
  March,
  2015. <P>
   <a href="docs/karim-usertrigger-c&s.pdf">Local</a> <p>
   <a href="http://www.sciencedirect.com/science/article/pii/S0167404814001631">Digital Library</a> <p>
  <B> Note: </B> &copy Copyright 2015 <a href="https://www.elsevier.com/about/company-information/policies/copyright"> Elsevier</a>. <P>

  <LI>
  Karim O. Elish and Danfeng Yao and Barbara G. Ryder,
  "User-centric Dependence Analysis for Identifying Malicious Mobile Apps",
  <I> Mobile Security Technologies workshop, </I>
  October,
  2012. <P>
   <a href="http://mostconf.org/2012/papers/20.pdf">Local</a> <p> 
  <B> Note: </B> &copy Copyright 2012 <a href=http://www.ieee.org/portal/index.jsp?pageID=corp_level1&path=about/documentation/copyright&file=index.xml&xsl=generic.xsl>IEEE</a>. <P>

