  <LI>
  Stephen Masticola,
  "Static Detection of Deadlocks in Polynomial Time",
  <I> Rutgers University, Ph.D. Thesis, </I>
  May,
  1993. <P>
   <a href="docs/lcsr-tr-208.ps.Z">Local</a> <p> 
  <B> Note: </B> Also available as LCSR-TR-208. <P>

  <LI>
  S. Masticola and B. G. Ryder,
  "Non-concurrency Analysis",
  <I>  Proceedings of Conference on Principles and Practices of Parallel Programming, </I>
  Pages 129-138,
  May,
  1993. <P>
  <B> Note: </B> Published as ACM SIGPLAN Notices, May 1993. <P>

  <LI>
  E. Schatz and B. G. Ryder,
  "Directed Tracing to Detect Race Conditions",
  <I> Proceedings of the International Conference on Parallel Processing, </I>
  August,
  1992. <P>
  <B> Note: </B> Longer version available as LCSR-TR-176. <P>

  <LI>
  E. Schatz and B. G. Ryder,
  "Directed Tracing to Detect Race Conditions",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-176,
  January,
  1992. <P>
  <B> Note: </B>  This is a fuller version of the ICPP92 paper. <P>

  <LI>
  S. Masticola and B. G. Ryder,
  "A model of Ada programs for static deadlock detection in polynomial times",
  <I>  Proceedings of 1991 ACM/ONR Workshop on Parallel and, </I>
  Pages 91-102,
  May,
  1991. <P>
  <B> Note: </B> Published as ACM SIGPLAN Notices, vol 26, no 12, December 1991. <P>

  <LI>
  E. Schatz and B. G. Ryder,
  "Directed Tracing to Detect Race Conditions",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-155,
  November,
  1990. <P>

  <LI>
  S. Masticola and B. G. Ryder,
  "Static Infinite Wait Anomaly Detection in Polynomial Time",
  <I> Proceedings of the International Conference on Parallel Processing, </I>
  Pages II78-II87,
  August,
  1990. <P>
  <B> Note: </B> Longer version available as LCSR-TR-141. <P>

