  <LI>
  Javier Elices,
  "Refining the Parallel Hybrid Algorithm for Data Flow Analysis",
  <I> Rutgers University, M. S. Thesis, </I>
  May,
  1996. <P>
  <B> Note: </B> Available as LCSR-TR-261. <P>

  <LI>
  Javier Elices,
  "The FM and PL Libraries Documentation",
  <I> Laboratory of Computer Science Research Technical Report, </I>
  Number LCSR-TR-257,
  January,
  1996. <P>
   <a href="docs/lcsr-tr-257-part1of3.ps.Z">Local</a> <p> 
  <B> Note: </B> This is a three part document. The URL here points to the first part of the document. The URL's to the other parts are similar, but end with 'part2of3.ps' and 'part3of3.ps'. <P>

  <LI>
  Yong-fong Lee, Barbara G. Ryder, and Marc E. Fiuczynski,
  "Region Analysis: A Parallel Elimination Method for Data Flow Analysis",
  <I> IEEE Transactions on Software Engineering, </I>
  Volume SE-21,
  Number 11,
  Pages 913-926,
  November,
  1995. <P>
   <a href="http://citeseer.ist.psu.edu/18168.html">Local</a> <p> 

  <LI>
  Vincent Sgro and Barbara G. Ryder,
  "Differences in Algorithmic Parallelism in Control Flow and Call Multigraphs",
  <I> Proceedings of the Seventh Annual Workshop on Languages and Compilers for Parallel Computing, LNCS 892, </I>
  Pages 217-233,
  August,
  1994. <P>
  <B> See also: </B> HPCD-TR-11. <P>

  <LI>
  Yong-fong Lee, Barbara G. Ryder, and Marc. E. Fiuczynski,
  "Region Analysis: A Parallel Elimination Method for Data Flow Analysis",
  <I> Proceedings of the IEEE Conference on Computer Languages, </I>
  Pages 31-42,
  May,
  1994. <P>

  <LI>
  Yong-fong Lee and Barbara G. Ryder,
  "Effectively Exploiting Parallelism in Data Flow Analysis",
  <I> The Journal of Supercomputing, </I>
  Pages 233-262,
  1994. <P>
  <B> See also: </B> LCSR-TR-192. <P>

  <LI>
  Yong-fong Lee and Barbara G. Ryder,
  "Parallel Hybrid Data Flow Algorithms: A Case Study",
  <I> Conference Record of 5th Workshop on Languages and Compilers for Parallel Computing, Yale University, LNCS 757, </I>
  Pages 296-310,
  August,
  1992. <P>

  <LI>
  Yong-fong Lee and Barbara G. Ryder,
  "A Comprehensive Approach to Parallel Data Flow Analysis",
  <I> Proceedings of the ACM International Conference on Supercomputing, </I>
  Pages 236-247,
  July,
  1992. <P>

  <LI>
  Yong-fong Lee,
  "Performing Data Flow Analysis in Parallel",
  <I> Rutgers University, Ph.D. Thesis, </I>
  May,
  1992. <P>
  <B> Note: </B> Also available as LCSR-TR-215. <P>

  <LI>
  Yong-fong Lee, Thomas J. Marlowe, and Barbara G. Ryder,
  "Experiences with a Parallel Algorithm for Data Flow Analysis",
  <I> The Journal of Supercomputing, </I>
  Volume 5,
  Number 2,
  Pages 163-188,
  October,
  1991. <P>

  <LI>
  Yong-fong Lee, Thomas J. Marlowe, and Barbara G. Ryder,
  "Performing Data Flow Analysis in Parallel",
  <I> Proceedings of ACM Supercomputing90, </I>
  Pages 942-951,
  November,
  1990. <P>
  <B> See also: </B> CAIP-TR-108. <P>

